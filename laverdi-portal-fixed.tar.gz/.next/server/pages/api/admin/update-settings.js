"use strict";(()=>{var e={};e.id=1,e.ids=[1],e.modules={2934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6689:e=>{e.exports=require("react")},6249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},9994:(e,t,r)=>{r.r(t),r.d(t,{config:()=>p,default:()=>u,routeModule:()=>f});var o={};r.r(o),r.d(o,{default:()=>c});var n=r(1802),i=r(7153),s=r(6249),a=r(2995),l=r(7997),d=r(9653);async function c(e,t){if("POST"!==e.method)return t.status(405).json({error:"Method not allowed"});try{let r=await (0,l.ts)();if(!r)return t.status(401).json({error:"Unauthorized"});let o=(0,a.i3)(),{action:n}=e.body;if("update_email"===n){let{new_email:n}=e.body;if(!n||"string"!=typeof n)return t.status(400).json({error:"Invalid email"});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(n))return t.status(400).json({error:"Invalid email format"});let{data:i}=await o.from("users").select("id").eq("email",n).neq("id",r.id).single();if(i)return t.status(400).json({error:"Email already in use"});let s=Math.floor(1e5+9e5*Math.random()).toString(),{error:a}=await o.from("email_verifications").insert({user_id:r.id,new_email:n,code:s,created_at:new Date().toISOString(),expires_at:new Date(Date.now()+9e5).toISOString()});if(a)return console.error("Error storing verification code:",a),t.status(500).json({error:"Failed to process email change"});try{await (0,d.Cz)({to:n,subject:"Verify your new email address - Laverdi.tech",html:`
            <h2>Verify Your Email Address</h2>
            <p>You requested to change your email address. Use this code to verify:</p>
            <p style="font-size: 24px; font-weight: bold; letter-spacing: 4px; font-family: monospace;">${s}</p>
            <p>This code expires in 15 minutes.</p>
            <p>If you didn't request this change, please ignore this email.</p>
          `})}catch(e){return console.error("Error sending verification email:",e),t.status(500).json({error:"Failed to send verification email"})}return t.status(200).json({message:"Verification email sent"})}if("verify_email"===n){let{code:n}=e.body;if(!n||"string"!=typeof n)return t.status(400).json({error:"Invalid verification code"});let{data:i,error:s}=await o.from("email_verifications").select("*").eq("user_id",r.id).eq("code",n).gt("expires_at",new Date().toISOString()).order("created_at",{ascending:!1}).limit(1).single();if(s||!i)return t.status(400).json({error:"Invalid or expired verification code"});let{error:a}=await o.from("users").update({email:i.new_email}).eq("id",r.id);if(a)return console.error("Error updating email:",a),t.status(500).json({error:"Failed to update email"});return await o.from("email_verifications").delete().eq("id",i.id),t.status(200).json({message:"Email updated successfully"})}if("update_preferences"===n){let{preferences:n}=e.body;if(!n||"object"!=typeof n)return t.status(400).json({error:"Invalid preferences"});let{data:i}=await o.from("user_preferences").select("id").eq("user_id",r.id).single();if(i){let{error:e}=await o.from("user_preferences").update({...n,updated_at:new Date().toISOString()}).eq("user_id",r.id);if(e)return console.error("Error updating preferences:",e),t.status(500).json({error:"Failed to update preferences"})}else{let{error:e}=await o.from("user_preferences").insert({user_id:r.id,...n,created_at:new Date().toISOString(),updated_at:new Date().toISOString()});if(e)return console.error("Error creating preferences:",e),t.status(500).json({error:"Failed to save preferences"})}return t.status(200).json({message:"Preferences updated successfully"})}return t.status(400).json({error:"Invalid action"})}catch(e){return console.error("Error updating settings:",e),t.status(500).json({error:"Internal server error"})}}let u=(0,s.l)(o,"default"),p=(0,s.l)(o,"config"),f=new n.PagesAPIRouteModule({definition:{kind:i.x.PAGES_API,page:"/api/admin/update-settings",pathname:"/api/admin/update-settings",bundlePath:"",filename:""},userland:o})},7997:(e,t,r)=>{r.d(t,{ts:()=>n});var o=r(2995);async function n(){let e=(0,o.AY)(),{data:{user:t}}=await e.auth.getUser();return t}},9653:(e,t,r)=>{r.d(t,{Cz:()=>a,w5:()=>c,nT:()=>d,Pi:()=>l});let o=require("nodemailer");var n=r.n(o);let i=null;function s(){if(i)return i;let e=process.env.SENDGRID_API_KEY;if(e)i=n().createTransport({host:"smtp.sendgrid.net",port:587,auth:{user:"apikey",pass:e}});else{let e=process.env.SMTP_HOST,t=parseInt(process.env.SMTP_PORT||"587"),r=process.env.SMTP_USER,o=process.env.SMTP_PASS;if(!e||!r||!o)return console.warn("Email service not configured. Please set SENDGRID_API_KEY or SMTP_* variables."),null;i=n().createTransport({host:e,port:t,secure:465===t,auth:{user:r,pass:o}})}return i}async function a(e){let t=s();if(!t)throw console.error("Email transporter not configured"),Error("Email service not available");let r=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech";try{await t.sendMail({from:r,to:e.to,subject:e.subject,html:e.html,text:e.text}),console.log(`Email sent to ${e.to}`)}catch(e){throw console.error("Failed to send email:",e),e}}async function l(e,t,r){let o=s();if(!o){console.error("Email transporter not configured");return}let n=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech",i=`
    <h2>Welcome to Laverdi.tech OpenClaw</h2>
    <p>Thank you for signing up for the <strong>${r}</strong> plan!</p>
    
    <h3>Your API Key</h3>
    <p><code>${t}</code></p>
    <p style="color: #666; font-size: 12px;">Keep this API key secure. Do not share it with anyone.</p>
    
    <h3>Getting Started</h3>
    <p>Visit your dashboard to:</p>
    <ul>
      <li>View API usage and analytics</li>
      <li>Manage multiple API keys</li>
      <li>Update subscription settings</li>
      <li>Access documentation</li>
    </ul>
    
    <p>Questions? Contact us at support@laverdi.tech</p>
  `;try{await o.sendMail({from:n,to:e,subject:"Welcome to Laverdi.tech OpenClaw - Your API Key",html:i}),console.log(`Welcome email sent to ${e}`)}catch(e){throw console.error("Failed to send welcome email:",e),e}}async function d(e,t,r,o){let n=s();if(!n){console.error("Email transporter not configured");return}let i=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech",a=`
    <h2>Payment Confirmation</h2>
    <p>Thank you for your payment!</p>
    
    <table style="width: 100%; border-collapse: collapse;">
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 8px; font-weight: bold;">Plan</td>
        <td style="padding: 8px;">${t}</td>
      </tr>
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 8px; font-weight: bold;">Amount</td>
        <td style="padding: 8px;">$${(r/100).toFixed(2)}</td>
      </tr>
    </table>
    
    <p style="margin-top: 20px;">
      <a href="${o}" style="background-color: #3B82F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
        View Invoice
      </a>
    </p>
  `;try{await n.sendMail({from:i,to:e,subject:"Payment Confirmation - Laverdi.tech OpenClaw",html:a}),console.log(`Receipt email sent to ${e}`)}catch(e){console.error("Failed to send receipt email:",e)}}async function c(e,t){let r=s();if(!r){console.error("Email transporter not configured");return}let o=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech",n=`
    <h2>Your OpenClaw Instance is Ready!</h2>
    <p>Great news! Your dedicated OpenClaw instance has been successfully provisioned and is now online.</p>
    
    <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
      <h3 style="margin-top: 0;">Instance Details</h3>
      <p style="margin-bottom: 5px;"><strong>IP Address:</strong> <code>${t}</code></p>
    </div>
    
    <h3>Next Steps</h3>
    <ol>
      <li>Open your local OpenClaw app</li>
      <li>Go to the <strong>Connect</strong> tab</li>
      <li>Select <strong>Remote VPS</strong></li>
      <li>Enter your instance IP address: <code>${t}</code></li>
    </ol>
    
    <p>If you have any questions or need help connecting, reply to this email or contact us at support@laverdi.tech</p>
  `;try{await r.sendMail({from:o,to:e,subject:"\uD83D\uDE80 Your OpenClaw Instance is Ready",html:n}),console.log(`Instance ready email sent to ${e}`)}catch(e){console.error("Failed to send instance ready email:",e)}}},2995:(e,t,r)=>{r.d(t,{i3:()=>l,AY:()=>a});let o=require("@supabase/ssr"),n="https://dcvrkpgvxqdcboostkpz.supabase.co",i="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRjdnJrcGd2eHFkY2Jvb3N0a3B6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUwMDYyODIsImV4cCI6MjA5MDU4MjI4Mn0.xgfGg_l1aXrlZX2Hjz45ZfGIFl8-JE3Dl8vmsrFhmKg",s=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!n||!i)throw Error("Missing Supabase credentials: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY (or NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY) are required");function a(){return(0,o.createBrowserClient)(n,i)}function l(){if(!s)throw Error("SUPABASE_SERVICE_ROLE_KEY is required for admin operations");return(0,o.createServerClient)(n,s,{cookies:{getAll:()=>[],setAll(){}}})}},7153:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},1802:(e,t,r)=>{e.exports=r(145)}};var t=require("../../../webpack-api-runtime.js");t.C(e);var r=t(t.s=9994);module.exports=r})();