"use strict";(()=>{var e={};e.id=269,e.ids=[269],e.modules={2934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6689:e=>{e.exports=require("react")},6249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},6799:(e,t,r)=>{r.r(t),r.d(t,{config:()=>p,default:()=>d,routeModule:()=>u});var o={};r.r(o),r.d(o,{default:()=>c});var n=r(1802),s=r(7153),a=r(6249),i=r(2995),l=r(9653);async function c(e,t){if("POST"!==e.method)return t.status(405).json({error:"Method not allowed"});let r=e.headers.authorization,o=process.env.DO_CALLBACK_SECRET||"fallback-secret-change-me";if(!r||r!==`Bearer ${o}`)return t.status(401).json({error:"Unauthorized"});let{user_id:n,droplet_ip:s,status:a}=e.body;if(!n||!s)return t.status(400).json({error:"Missing required payload fields"});try{console.log(`Received callback for user ${n}: Droplet ready at ${s}`);try{let e=(0,i.i3)(),{error:t}=await e.from("instances").update({status:a||"ready",ip_address:s,updated_at:new Date().toISOString()}).eq("user_id",n);if(t)console.error("Supabase update error (instances table):",t.message);else{let{data:t,error:r}=await e.from("users").select("email").eq("id",n).single();r||!t?.email?console.error("Failed to fetch user email for notification:",r?.message):await (0,l.w5)(t.email,s)}}catch(e){console.error("Database error in callback:",e)}return t.status(200).json({success:!0,message:"Callback received successfully"})}catch(e){return console.error("DO Callback Error:",e),t.status(500).json({error:"Internal server error",message:e.message})}}let d=(0,a.l)(o,"default"),p=(0,a.l)(o,"config"),u=new n.PagesAPIRouteModule({definition:{kind:s.x.PAGES_API,page:"/api/webhooks/do-callback",pathname:"/api/webhooks/do-callback",bundlePath:"",filename:""},userland:o})},9653:(e,t,r)=>{r.d(t,{Cz:()=>i,w5:()=>d,nT:()=>c,Pi:()=>l});let o=require("nodemailer");var n=r.n(o);let s=null;function a(){if(s)return s;let e=process.env.SENDGRID_API_KEY;if(e)s=n().createTransport({host:"smtp.sendgrid.net",port:587,auth:{user:"apikey",pass:e}});else{let e=process.env.SMTP_HOST,t=parseInt(process.env.SMTP_PORT||"587"),r=process.env.SMTP_USER,o=process.env.SMTP_PASS;if(!e||!r||!o)return console.warn("Email service not configured. Please set SENDGRID_API_KEY or SMTP_* variables."),null;s=n().createTransport({host:e,port:t,secure:465===t,auth:{user:r,pass:o}})}return s}async function i(e){let t=a();if(!t)throw console.error("Email transporter not configured"),Error("Email service not available");let r=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech";try{await t.sendMail({from:r,to:e.to,subject:e.subject,html:e.html,text:e.text}),console.log(`Email sent to ${e.to}`)}catch(e){throw console.error("Failed to send email:",e),e}}async function l(e,t,r){let o=a();if(!o){console.error("Email transporter not configured");return}let n=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech",s=`
    <h2>Welcome to Laverdi.tech OpenClaw</h2>
    <p>Thank you for signing up for the <strong>${r}</strong> plan!</p>
    
    <h3>Your API Key</h3>
    <p><code>${t}</code></p>
    <p style="color: #666; font-size: 12px;">Keep this API key secure. Do not share it with anyone.</p>
    
    <h3>Getting Started</h3>
    <p>Visit your dashboard to:</p>
    <ul>
      <li>View API usage and analytics</li>
      <li>Manage multiple API keys</li>
      <li>Update subscription settings</li>
      <li>Access documentation</li>
    </ul>
    
    <p>Questions? Contact us at support@laverdi.tech</p>
  `;try{await o.sendMail({from:n,to:e,subject:"Welcome to Laverdi.tech OpenClaw - Your API Key",html:s}),console.log(`Welcome email sent to ${e}`)}catch(e){throw console.error("Failed to send welcome email:",e),e}}async function c(e,t,r,o){let n=a();if(!n){console.error("Email transporter not configured");return}let s=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech",i=`
    <h2>Payment Confirmation</h2>
    <p>Thank you for your payment!</p>
    
    <table style="width: 100%; border-collapse: collapse;">
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 8px; font-weight: bold;">Plan</td>
        <td style="padding: 8px;">${t}</td>
      </tr>
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 8px; font-weight: bold;">Amount</td>
        <td style="padding: 8px;">$${(r/100).toFixed(2)}</td>
      </tr>
    </table>
    
    <p style="margin-top: 20px;">
      <a href="${o}" style="background-color: #3B82F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
        View Invoice
      </a>
    </p>
  `;try{await n.sendMail({from:s,to:e,subject:"Payment Confirmation - Laverdi.tech OpenClaw",html:i}),console.log(`Receipt email sent to ${e}`)}catch(e){console.error("Failed to send receipt email:",e)}}async function d(e,t){let r=a();if(!r){console.error("Email transporter not configured");return}let o=process.env.SENDGRID_FROM_EMAIL||"noreply@laverdi.tech",n=`
    <h2>Your OpenClaw Instance is Ready!</h2>
    <p>Great news! Your dedicated OpenClaw instance has been successfully provisioned and is now online.</p>
    
    <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
      <h3 style="margin-top: 0;">Instance Details</h3>
      <p style="margin-bottom: 5px;"><strong>IP Address:</strong> <code>${t}</code></p>
    </div>
    
    <h3>Next Steps</h3>
    <ol>
      <li>Open your local OpenClaw app</li>
      <li>Go to the <strong>Connect</strong> tab</li>
      <li>Select <strong>Remote VPS</strong></li>
      <li>Enter your instance IP address: <code>${t}</code></li>
    </ol>
    
    <p>If you have any questions or need help connecting, reply to this email or contact us at support@laverdi.tech</p>
  `;try{await r.sendMail({from:o,to:e,subject:"\uD83D\uDE80 Your OpenClaw Instance is Ready",html:n}),console.log(`Instance ready email sent to ${e}`)}catch(e){console.error("Failed to send instance ready email:",e)}}},2995:(e,t,r)=>{r.d(t,{i3:()=>l,AY:()=>i});let o=require("@supabase/ssr"),n="https://dcvrkpgvxqdcboostkpz.supabase.co",s="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRjdnJrcGd2eHFkY2Jvb3N0a3B6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUwMDYyODIsImV4cCI6MjA5MDU4MjI4Mn0.xgfGg_l1aXrlZX2Hjz45ZfGIFl8-JE3Dl8vmsrFhmKg",a=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!n||!s)throw Error("Missing Supabase credentials: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY (or NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY) are required");function i(){return(0,o.createBrowserClient)(n,s)}function l(){if(!a)throw Error("SUPABASE_SERVICE_ROLE_KEY is required for admin operations");return(0,o.createServerClient)(n,a,{cookies:{getAll:()=>[],setAll(){}}})}},7153:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},1802:(e,t,r)=>{e.exports=r(145)}};var t=require("../../../webpack-api-runtime.js");t.C(e);var r=t(t.s=6799);module.exports=r})();