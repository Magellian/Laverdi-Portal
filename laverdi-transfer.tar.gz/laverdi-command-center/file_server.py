"""
Lightweight file server for OpenClaw containers.
Provides browse/download/preview access to the workspace folder.
Runs on port 8701 inside each container.
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import mimetypes
import urllib.parse
import zipfile
import io
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

WORKSPACE_ROOT = os.environ.get('WORKSPACE_PATH', '/root/.openclaw/workspace')
PORT = int(os.environ.get('FILE_SERVER_PORT', '8701'))
AUTH_TOKEN = os.environ.get('FILE_AUTH_TOKEN', '')

# Max file size for preview (1MB)
MAX_PREVIEW_SIZE = 1024 * 1024

# Text file extensions for preview
TEXT_EXTENSIONS = {
    '.txt', '.md', '.py', '.js', '.ts', '.tsx', '.jsx', '.json', '.yaml', '.yml',
    '.toml', '.cfg', '.ini', '.sh', '.bash', '.zsh', '.fish', '.ps1',
    '.html', '.css', '.scss', '.less', '.xml', '.svg', '.sql',
    '.env', '.gitignore', '.dockerignore', '.editorconfig',
    '.rs', '.go', '.java', '.c', '.cpp', '.h', '.hpp', '.rb', '.php',
    '.r', '.m', '.swift', '.kt', '.scala', '.lua', '.pl', '.ex', '.exs',
    '.log', '.csv', '.tsv',
}


class FileHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.info(format % args)

    def do_GET(self):
        # Parse URL
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        action = params.get('action', ['list'])[0]
        rel_path = params.get('path', ['/'])[0]

        # Security: prevent path traversal
        rel_path = os.path.normpath(rel_path).lstrip(os.sep)
        full_path = os.path.join(WORKSPACE_ROOT, rel_path)
        full_path = os.path.realpath(full_path)

        if not full_path.startswith(os.path.realpath(WORKSPACE_ROOT)):
            self.send_error(403, 'Access denied')
            return

        if action == 'list':
            self.handle_list(full_path, rel_path)
        elif action == 'download':
            self.handle_download(full_path)
        elif action == 'preview':
            self.handle_preview(full_path)
        elif action == 'zip':
            self.handle_zip(full_path, rel_path)
        else:
            self.send_error(400, 'Invalid action')

    def handle_list(self, full_path, rel_path):
        """List directory contents."""
        if not os.path.exists(full_path):
            # Return empty list for non-existent paths
            self.send_json({'path': rel_path or '/', 'items': [], 'exists': False})
            return

        if not os.path.isdir(full_path):
            self.send_error(400, 'Not a directory')
            return

        items = []
        try:
            for entry in sorted(os.listdir(full_path)):
                entry_path = os.path.join(full_path, entry)
                stat = os.stat(entry_path)
                is_dir = os.path.isdir(entry_path)

                items.append({
                    'name': entry,
                    'path': os.path.join(rel_path or '', entry).replace('\\', '/'),
                    'type': 'directory' if is_dir else 'file',
                    'size': stat.st_size if not is_dir else None,
                    'modified': stat.st_mtime,
                    'extension': os.path.splitext(entry)[1].lower() if not is_dir else None,
                })
        except PermissionError:
            self.send_error(403, 'Permission denied')
            return

        self.send_json({
            'path': rel_path or '/',
            'items': items,
            'exists': True,
            'count': len(items),
        })

    def handle_download(self, full_path):
        """Download a file."""
        if not os.path.isfile(full_path):
            self.send_error(404, 'File not found')
            return

        mime_type = mimetypes.guess_type(full_path)[0] or 'application/octet-stream'
        filename = os.path.basename(full_path)

        try:
            with open(full_path, 'rb') as f:
                data = f.read()

            self.send_response(200)
            self.send_header('Content-Type', mime_type)
            self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self.send_error(500, str(e))

    def handle_preview(self, full_path):
        """Preview text file content."""
        if not os.path.isfile(full_path):
            self.send_error(404, 'File not found')
            return

        ext = os.path.splitext(full_path)[1].lower()
        size = os.path.getsize(full_path)

        if ext not in TEXT_EXTENSIONS and size > MAX_PREVIEW_SIZE:
            self.send_json({
                'preview': False,
                'reason': 'File too large or not a text file',
                'size': size,
            })
            return

        try:
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read(MAX_PREVIEW_SIZE)

            truncated = size > MAX_PREVIEW_SIZE
            self.send_json({
                'preview': True,
                'content': content,
                'size': size,
                'truncated': truncated,
                'extension': ext,
                'filename': os.path.basename(full_path),
            })
        except Exception as e:
            self.send_json({
                'preview': False,
                'reason': str(e),
            })

    def handle_zip(self, full_path, rel_path):
        """Download a directory as a zip file."""
        if not os.path.isdir(full_path):
            self.send_error(400, 'Not a directory')
            return

        try:
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
                for root, dirs, files in os.walk(full_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arc_name = os.path.relpath(file_path, full_path)
                        zf.write(file_path, arc_name)

            data = buf.getvalue()
            dirname = os.path.basename(full_path) or 'workspace'

            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', f'attachment; filename="{dirname}.zip"')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self.send_error(500, str(e))

    def send_json(self, data):
        """Send JSON response."""
        body = json.dumps(data).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)


if __name__ == '__main__':
    logger.info(f'File server starting on port {PORT}')
    logger.info(f'Serving workspace: {WORKSPACE_ROOT}')
    server = HTTPServer(('0.0.0.0', PORT), FileHandler)
    server.serve_forever()
