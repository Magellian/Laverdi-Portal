/**
 * Lightweight file server for OpenClaw containers.
 * Provides browse/download/preview access to the workspace folder.
 * Runs on port 8701 inside each container.
 * No dependencies — uses only Node.js built-ins.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

// Auto-detect workspace path — some containers use double .openclaw nesting
const WORKSPACE = (function() {
  const candidates = [
    process.env.WORKSPACE_PATH,
    '/root/.openclaw/.openclaw/workspace',
    '/root/.openclaw/workspace',
    '/home/openclaw/.openclaw/workspace',
  ];
  const fs = require('fs');
  for (const p of candidates) {
    if (p && fs.existsSync(p)) return p;
  }
  return '/root/.openclaw/workspace';
})();
const PORT = parseInt(process.env.FILE_SERVER_PORT || '8701');

const TEXT_EXT = new Set([
  '.txt', '.md', '.py', '.js', '.ts', '.tsx', '.jsx', '.json', '.yaml', '.yml',
  '.toml', '.cfg', '.ini', '.sh', '.bash', '.html', '.css', '.xml', '.svg',
  '.sql', '.env', '.gitignore', '.log', '.csv',
  '.rs', '.go', '.java', '.c', '.cpp', '.h', '.rb', '.php', '.swift',
]);

function safePath(reqPath) {
  const normalized = path.normalize(reqPath || '/').replace(/^[/\\]+/, '');
  const full = path.resolve(WORKSPACE, normalized);
  if (!full.startsWith(path.resolve(WORKSPACE))) return null;
  return full;
}

function formatJSON(res, data) {
  const body = JSON.stringify(data);
  res.writeHead(200, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function handleList(res, fullPath, relPath) {
  if (!fs.existsSync(fullPath)) {
    return formatJSON(res, { path: relPath || '/', items: [], exists: false });
  }
  if (!fs.statSync(fullPath).isDirectory()) {
    res.writeHead(400); res.end('Not a directory'); return;
  }

  const entries = fs.readdirSync(fullPath);
  const items = entries.sort().map(name => {
    const fp = path.join(fullPath, name);
    try {
      const stat = fs.statSync(fp);
      const isDir = stat.isDirectory();
      return {
        name,
        path: path.join(relPath || '', name).replace(/\\/g, '/'),
        type: isDir ? 'directory' : 'file',
        size: isDir ? null : stat.size,
        modified: stat.mtimeMs / 1000,
        extension: isDir ? null : path.extname(name).toLowerCase(),
      };
    } catch { return null; }
  }).filter(Boolean);

  formatJSON(res, { path: relPath || '/', items, exists: true, count: items.length });
}

function handleDownload(res, fullPath) {
  if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isFile()) {
    res.writeHead(404); res.end('File not found'); return;
  }
  const filename = path.basename(fullPath);
  const data = fs.readFileSync(fullPath);
  res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Content-Length': data.length,
    'Access-Control-Allow-Origin': '*',
  });
  res.end(data);
}

function handlePreview(res, fullPath) {
  if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isFile()) {
    res.writeHead(404); res.end('File not found'); return;
  }
  const ext = path.extname(fullPath).toLowerCase();
  const size = fs.statSync(fullPath).size;
  const maxSize = 1024 * 1024;

  if (!TEXT_EXT.has(ext) && size > maxSize) {
    return formatJSON(res, { preview: false, reason: 'File too large or binary', size });
  }
  try {
    const content = fs.readFileSync(fullPath, 'utf-8').slice(0, maxSize);
    formatJSON(res, {
      preview: true, content, size,
      truncated: size > maxSize,
      extension: ext,
      filename: path.basename(fullPath),
    });
  } catch (e) {
    formatJSON(res, { preview: false, reason: e.message });
  }
}

function handleZip(res, fullPath) {
  // Simple tar-like concatenation since we can't use zlib easily
  // Actually Node has zlib built in, let's use it
  if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isDirectory()) {
    res.writeHead(400); res.end('Not a directory'); return;
  }

  // Collect all files
  const files = [];
  function walk(dir, prefix) {
    for (const name of fs.readdirSync(dir)) {
      const fp = path.join(dir, name);
      const rel = prefix ? prefix + '/' + name : name;
      try {
        if (fs.statSync(fp).isDirectory()) {
          walk(fp, rel);
        } else {
          files.push({ path: rel, fullPath: fp });
        }
      } catch {}
    }
  }
  walk(fullPath, '');

  // Build a simple JSON manifest + files (not a real zip, but downloadable)
  // For a real zip we'd need a library. Let's just offer individual downloads for now.
  formatJSON(res, {
    type: 'directory',
    path: path.basename(fullPath),
    files: files.map(f => ({
      path: f.path,
      size: fs.statSync(f.fullPath).size,
    })),
    count: files.length,
    message: 'Use individual file downloads. Zip support coming soon.',
  });
}

const server = http.createServer((req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET', 'Access-Control-Allow-Headers': '*' });
    res.end(); return;
  }
  if (req.method !== 'GET') { res.writeHead(405); res.end('Method not allowed'); return; }

  const parsed = url.parse(req.url, true);
  const action = parsed.query.action || 'list';
  const reqPath = parsed.query.path || '/';
  const fullPath = safePath(reqPath);

  if (!fullPath) { res.writeHead(403); res.end('Access denied'); return; }

  try {
    if (action === 'list') handleList(res, fullPath, reqPath);
    else if (action === 'download') handleDownload(res, fullPath);
    else if (action === 'preview') handlePreview(res, fullPath);
    else if (action === 'zip') handleZip(res, fullPath);
    else { res.writeHead(400); res.end('Invalid action'); }
  } catch (e) {
    console.error('Error:', e);
    res.writeHead(500); res.end(e.message);
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`File server running on port ${PORT}`);
  console.log(`Serving: ${WORKSPACE}`);
});
