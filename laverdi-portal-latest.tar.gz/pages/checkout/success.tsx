import { useEffect } from 'react'
import { useRouter } from 'next/router'
import Link from 'next/link'
import Head from 'next/head'

export default function CheckoutSuccess() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to dashboard after 3 seconds
    const timer = setTimeout(() => {
      router.push('/dashboard')
    }, 3000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <>
      <Head>
        <title>Payment Successful - Laverdi.tech</title>
      </Head>

      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center">
          <div className="text-6xl mb-6">✅</div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Payment Successful!
          </h1>
          <p className="text-gray-600 mb-2">
            Thank you for your subscription!
          </p>
          <p className="text-gray-600 mb-8">
            Check your email for your API key and getting started guide.
          </p>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-8 text-left">
            <p className="text-gray-700 text-sm">
              You will be redirected to your dashboard in 3 seconds...
            </p>
          </div>

          <Link
            href="/dashboard"
            className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Go to Dashboard Now
          </Link>
        </div>
      </div>
    </>
  )
}
