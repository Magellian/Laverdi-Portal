/**
 * pages/index.tsx
 * Laverdi Landing Page - Phase 3 Complete Implementation
 * 
 * DESIGN SPECIFICATIONS:
 * - Brand Colors: Deep Red (#FF3333) + Black (#1A1A1A) + White (#FFFFFF)
 * - Font: Inter (all sizes)
 * - Mobile-First Responsive (375px - 1440px)
 * - All 10 sections fully implemented
 * - Hero with Molty animation integration
 * - Smooth scrolling, hover effects, transitions
 * 
 * SECTIONS:
 * 1. Header (logo + nav + CTA)
 * 2. Hero (headline + subheadline + Molty + CTAs)
 * 3. Trial banner (notification style)
 * 4. How-it-works (3-column flow)
 * 5. Why-laverdi (4 feature cards)
 * 6. Pricing (3 tiers + Enterprise)
 * 7. Quickstart (5-step timeline)
 * 8. Community (social links)
 * 9. Security (3 trust points)
 * 10. CTA footer
 */

'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  Mail,
  CheckCircle,
  Settings,
  FileText,
  Link as LinkIcon,
  Clock,
  ArrowRight,
  Shield,
  Zap,
  Users,
  // Github,
  // Twitter,
  // Linkedin,
} from 'lucide-react';
import { Molty2D } from '../components/Molty2D';

const LandingPage = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Head metadata would go here in Next.js */}

      {/* ============================================
          1. HEADER & NAVIGATION
          ============================================ */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link href="/" className="flex items-center gap-2">
                <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">L</span>
                </div>
                <span className="text-xl font-bold text-black hidden sm:inline">
                  Laverdi
                </span>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <Link
                href="#how-it-works"
                className="text-gray-700 hover:text-red-600 transition-colors font-medium"
              >
                How It Works
              </Link>
              <Link
                href="#pricing"
                className="text-gray-700 hover:text-red-600 transition-colors font-medium"
              >
                Pricing
              </Link>
              <Link
                href="#why-laverdi"
                className="text-gray-700 hover:text-red-600 transition-colors font-medium"
              >
                Why Laverdi
              </Link>
              <Link
                href="#community"
                className="text-gray-700 hover:text-red-600 transition-colors font-medium"
              >
                Community
              </Link>
            </nav>

            {/* CTA Button */}
            <div className="flex items-center gap-4">
              <Link
                href="/auth/signup"
                className="hidden sm:inline-block px-6 py-2 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200"
              >
                Get Started
              </Link>

              {/* Mobile Menu Button */}
              <button
                className="md:hidden p-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 border-t border-gray-100">
              <nav className="flex flex-col gap-4 py-4">
                <Link
                  href="#how-it-works"
                  className="text-gray-700 hover:text-red-600 transition-colors font-medium px-2"
                >
                  How It Works
                </Link>
                <Link
                  href="#pricing"
                  className="text-gray-700 hover:text-red-600 transition-colors font-medium px-2"
                >
                  Pricing
                </Link>
                <Link
                  href="#why-laverdi"
                  className="text-gray-700 hover:text-red-600 transition-colors font-medium px-2"
                >
                  Why Laverdi
                </Link>
                <Link
                  href="#community"
                  className="text-gray-700 hover:text-red-600 transition-colors font-medium px-2"
                >
                  Community
                </Link>
                <Link
                  href="/auth/signup"
                  className="px-4 py-2 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200 text-center"
                >
                  Get Started
                </Link>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* ============================================
          2. HERO SECTION
          ============================================ */}
      <section className="relative py-12 md:py-24 overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-red-50 via-white to-gray-50 -z-10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
            {/* Left: Content */}
            <div className="space-y-6 md:space-y-8">
              <div className="inline-block px-4 py-2 bg-red-100 rounded-full">
                <span className="text-red-600 font-semibold text-sm">
                  🤖 Your Personal AI Assistant on VPS
                </span>
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-black leading-tight">
                Rent an AI Assistant. Deployed. Ready. Now.
              </h1>

              <p className="text-lg md:text-xl text-gray-600 leading-relaxed max-w-xl">
                Get a personal AI assistant running on your own VPS. Full control, zero setup hassle.
                Built on OpenClaw. Ready for your business.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link
                  href="/auth/signup"
                  className="px-8 py-4 bg-red-600 text-white rounded-lg font-bold text-lg hover:bg-red-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
                >
                  Deploy Now
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  href="#how-it-works"
                  className="px-8 py-4 border-2 border-black text-black rounded-lg font-bold text-lg hover:bg-black hover:text-white transition-all duration-200 flex items-center justify-center gap-2"
                >
                  See How It Works
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </div>

              {/* Trust badges */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span>Your own VPS included</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span>7-day free trial</span>
                </div>
              </div>
            </div>

            {/* Right: Hero Visual (Molty 2D Animation) */}
            <div className="relative hidden lg:flex items-center justify-center h-96 w-full">
              <div className="w-64 h-64">
                <Molty2D />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================
          3. TRIAL BANNER
          ============================================ */}
      <section className="py-6 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-center">
            <div className="flex items-center gap-3">
              <Clock className="w-6 h-6 text-red-400 flex-shrink-0" />
              <div>
                <p className="font-bold text-lg">
                  7-Day Free Trial • VPS Included • No Credit Card
                </p>
                <p className="text-gray-300 text-sm">
                  Full access to everything. Cancel anytime. Zero commitment.
                </p>
              </div>
            </div>
            <Link
              href="/auth/signup"
              className="px-6 py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200 whitespace-nowrap"
            >
              Deploy Now
            </Link>
          </div>
        </div>
      </section>

      {/* ============================================
          4. HOW IT WORKS (3-Column)
          ============================================ */}
      <section id="how-it-works" className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-4">
              How It Works
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From signup to running agent in minutes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-6">
            {/* Step 1 */}
            <div className="relative bg-gradient-to-br from-red-50 to-white border-2 border-red-200 rounded-2xl p-8">
              <div className="absolute top-0 left-8 -translate-y-1/2 w-12 h-12 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-xl">
                1
              </div>
              <div className="mt-6 space-y-4">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <Mail className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-black">Create Account</h3>
                <p className="text-gray-600">
                  Sign up with your email. Verify in seconds. No credit card needed for trial.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative bg-gradient-to-br from-red-50 to-white border-2 border-red-200 rounded-2xl p-8">
              <div className="absolute top-0 left-8 -translate-y-1/2 w-12 h-12 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-xl">
                2
              </div>
              <div className="mt-6 space-y-4">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <Zap className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-black">Deploy Agent</h3>
                <p className="text-gray-600">
                  Choose your plan. We provision a VPS and deploy your personal AI assistant.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative bg-gradient-to-br from-red-50 to-white border-2 border-red-200 rounded-2xl p-8">
              <div className="absolute top-0 left-8 -translate-y-1/2 w-12 h-12 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-xl">
                3
              </div>
              <div className="mt-6 space-y-4">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-black">Start Using</h3>
                <p className="text-gray-600">
                  API keys, dashboard, and full control. Your agent is ready to work immediately.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================
          5. WHY OPENCLAW (4 Feature Cards)
          ============================================ */}
      <section id="why-laverdi" className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-4">
              Why OpenClaw?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Rent an AI that understands your business. No expertise required.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Feature 1 */}
            <div className="bg-white rounded-2xl p-8 border border-gray-200 hover:shadow-lg transition-shadow duration-300">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <Settings className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-3">Full Control</h3>
              <p className="text-gray-600 leading-relaxed">
                Your own VPS, your own agent, your own data. Complete control over the entire system.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-white rounded-2xl p-8 border border-gray-200 hover:shadow-lg transition-shadow duration-300">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <FileText className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-3">Customizable Agent</h3>
              <p className="text-gray-600 leading-relaxed">
                Tailor your assistant to your needs. Change prompts, add tools, build automations.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-white rounded-2xl p-8 border border-gray-200 hover:shadow-lg transition-shadow duration-300">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <Users className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-3">No Vendor Lock-In</h3>
              <p className="text-gray-600 leading-relaxed">
                Open source. Open architecture. Export your data anytime. You own everything.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="bg-white rounded-2xl p-8 border border-gray-200 hover:shadow-lg transition-shadow duration-300">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-2xl font-bold text-black mb-3">Privacy First</h3>
              <p className="text-gray-600 leading-relaxed">
                Data stays on your VPS. No third-party tracking. GDPR compliant by design.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================
          6. PRICING (3 Tiers + Enterprise)
          ============================================ */}
      <section id="pricing" className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Choose the plan that fits your portfolio. Scale up whenever you're ready.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Free Tier */}
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-black mb-2">Free</h3>
              <p className="text-gray-600 mb-6">7-day trial to test drive</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-black">$0</span>
                <span className="text-gray-600">/month</span>
              </div>
              <Link
                href="/auth/signup"
                className="w-full px-6 py-3 border-2 border-black text-black rounded-lg font-bold hover:bg-black hover:text-white transition-colors duration-200 text-center block mb-8"
              >
                Start Trial
              </Link>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">100 API calls/month</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">Full VPS access</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">Dashboard & API keys</span>
                </li>
              </ul>
            </div>

            {/* Starter Tier (Featured) */}
            <div className="bg-black text-white rounded-2xl p-8 relative transform md:scale-105 md:-my-4">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-red-600 px-4 py-1 rounded-full">
                <span className="font-bold text-sm">Most Popular</span>
              </div>
              <h3 className="text-2xl font-bold mb-2">Starter</h3>
              <p className="text-gray-300 mb-6">Perfect for startups & solopreneurs</p>
              <div className="mb-6">
                <span className="text-4xl font-bold">$29</span>
                <span className="text-gray-400">/month</span>
              </div>
              <Link
                href="/auth/signup"
                className="w-full px-6 py-3 bg-red-600 text-white rounded-lg font-bold hover:bg-red-700 transition-colors duration-200 text-center block mb-8"
              >
                Get Started
              </Link>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                  <span>10k API calls/month</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                  <span>Sonnet 4.6 primary model</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                  <span>Full customization</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                  <span>Email support</span>
                </li>
              </ul>
            </div>

            {/* Pro Tier */}
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-black mb-2">Pro</h3>
              <p className="text-gray-600 mb-6">For agencies & enterprises</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-black">$99</span>
                <span className="text-gray-600">/month</span>
              </div>
              <Link
                href="/auth/signup"
                className="w-full px-6 py-3 border-2 border-black text-black rounded-lg font-bold hover:bg-black hover:text-white transition-colors duration-200 text-center block mb-8"
              >
                Get Started
              </Link>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">100k API calls/month</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">Opus 4.6 primary model</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">Priority support</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">Dedicated account manager</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================
          7. QUICKSTART (5-Step Timeline)
          ============================================ */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-4">
              Get Started in 5 Minutes
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From signup to your first automated workflow, all in one quick setup.
            </p>
          </div>

          <div className="relative max-w-2xl mx-auto">
            {/* Timeline line */}
            <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-red-600 to-red-300 -translate-x-1/2" />

            <div className="space-y-8 md:space-y-12">
              {/* Step 1 */}
              <div className="flex gap-4 md:gap-8">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-10 h-10 bg-red-600 text-white rounded-full font-bold relative z-10">
                    1
                  </div>
                </div>
                <div className="flex-1 pt-1">
                  <h3 className="text-xl font-bold text-black mb-2">Sign Up & Create Account</h3>
                  <p className="text-gray-600">
                    Enter your email and confirm. No credit card needed.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex gap-4 md:gap-8">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-10 h-10 bg-red-600 text-white rounded-full font-bold relative z-10">
                    2
                  </div>
                </div>
                <div className="flex-1 pt-1">
                  <h3 className="text-xl font-bold text-black mb-2">Add Your First Property</h3>
                  <p className="text-gray-600">
                    Input basic property details. Takes less than a minute.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex gap-4 md:gap-8">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-10 h-10 bg-red-600 text-white rounded-full font-bold relative z-10">
                    3
                  </div>
                </div>
                <div className="flex-1 pt-1">
                  <h3 className="text-xl font-bold text-black mb-2">Upload Documents</h3>
                  <p className="text-gray-600">
                    Drag and drop leases, contracts, or any files. Molty reads them instantly.
                  </p>
                </div>
              </div>

              {/* Step 4 */}
              <div className="flex gap-4 md:gap-8">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-10 h-10 bg-red-600 text-white rounded-full font-bold relative z-10">
                    4
                  </div>
                </div>
                <div className="flex-1 pt-1">
                  <h3 className="text-xl font-bold text-black mb-2">Invite Tenants</h3>
                  <p className="text-gray-600">
                    Share tenant portal access. They can pay rent and submit requests directly.
                  </p>
                </div>
              </div>

              {/* Step 5 */}
              <div className="flex gap-4 md:gap-8">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-10 h-10 bg-red-600 text-white rounded-full font-bold relative z-10">
                    5
                  </div>
                </div>
                <div className="flex-1 pt-1">
                  <h3 className="text-xl font-bold text-black mb-2">Let Molty Work</h3>
                  <p className="text-gray-600">
                    AI starts generating insights. Check your dashboard for recommendations.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link
              href="/auth/signup"
              className="inline-block px-8 py-4 bg-red-600 text-white rounded-lg font-bold text-lg hover:bg-red-700 transition-colors duration-200 flex items-center justify-center gap-2"
            >
              Start Your Free Trial
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* ============================================
          8. COMMUNITY (Social Links)
          ============================================ */}
      <section id="community" className="py-16 md:py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Join Our Community
            </h2>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Connect with property managers, share best practices, and get early access to new features.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-2xl mx-auto">
            {/* GitHub */}
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 p-6 bg-gray-900 hover:bg-red-600 rounded-lg transition-colors duration-200"
            >
              <span className="font-semibold">GitHub</span>
            </a>

            {/* Twitter */}
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 p-6 bg-gray-900 hover:bg-red-600 rounded-lg transition-colors duration-200"
            >
              <span className="font-semibold">Twitter</span>
            </a>

            {/* LinkedIn */}
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 p-6 bg-gray-900 hover:bg-red-600 rounded-lg transition-colors duration-200"
            >
              <span className="font-semibold">LinkedIn</span>
            </a>
          </div>
        </div>
      </section>

      {/* ============================================
          9. SECURITY & TRUST
          ============================================ */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-4">
              Enterprise Security You Can Trust
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Your data security is our top priority. Here's what we provide.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Security 1 */}
            <div className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-black mb-3">Bank-Level Encryption</h3>
              <p className="text-gray-600">
                AES-256 encryption for data at rest. TLS 1.3 for data in transit. HIPAA & GDPR compliant.
              </p>
            </div>

            {/* Security 2 */}
            <div className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-black mb-3">Role-Based Access Control</h3>
              <p className="text-gray-600">
                Fine-grained permissions. Admin, manager, and viewer roles. Audit logs for all actions.
              </p>
            </div>

            {/* Security 3 */}
            <div className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-black mb-3">Certified & Audited</h3>
              <p className="text-gray-600">
                SOC 2 Type II certified. Regular penetration testing. Transparent security practices.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================
          10. CTA FOOTER
          ============================================ */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-black via-gray-900 to-black text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Deploy Your AI?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Get your personal OpenClaw agent running on your own VPS. 7-day free trial. No credit card.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/auth/signup"
              className="px-8 py-4 bg-red-600 text-white rounded-lg font-bold text-lg hover:bg-red-700 transition-colors duration-200 flex items-center justify-center gap-2"
            >
              Deploy Now
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="mailto:support@laverdi.tech"
              className="px-8 py-4 border-2 border-white text-white rounded-lg font-bold text-lg hover:bg-white hover:text-black transition-colors duration-200 flex items-center justify-center gap-2"
            >
              Questions?
              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* ============================================
          FOOTER
          ============================================ */}
      <footer className="bg-black text-gray-400 py-8 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">L</span>
                </div>
                <span className="text-white font-bold text-lg">Laverdi</span>
              </div>
              <p className="text-sm text-gray-500">
                Intelligent property management for modern operators.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="hover:text-red-600 transition-colors">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    Security
                  </a>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    Careers
                  </a>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    Terms
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-red-600 transition-colors">
                    Cookie Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">
              © 2026 Laverdi. All rights reserved.
            </p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-500 hover:text-red-600 transition-colors font-medium">
                GitHub
              </a>
              <a href="#" className="text-gray-500 hover:text-red-600 transition-colors font-medium">
                Twitter
              </a>
              <a href="#" className="text-gray-500 hover:text-red-600 transition-colors font-medium">
                LinkedIn
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
