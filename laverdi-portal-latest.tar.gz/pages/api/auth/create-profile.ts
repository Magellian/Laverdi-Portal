import type { NextApiRequest, NextApiResponse } from 'next'
import { createAdminClient } from '@/lib/supabase'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { userId, email } = req.body

    if (!userId || !email) {
      return res.status(400).json({ error: 'Missing userId or email' })
    }

    const supabaseAdmin = createAdminClient()

    // Check if profile already exists
    const { data: existing, error: checkError } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('id', userId)
      .single()

    if (checkError && checkError.code !== 'PGRST116') {
      // PGRST116 = no rows found (expected)
      console.error('Error checking profile:', checkError)
      // Don't fail here - proceed with insert attempt
    }

    if (existing) {
      console.log('Profile already exists:', userId)
      return res.status(200).json({ success: true, message: 'Profile already exists' })
    }

    // Create user profile
    const apiKey = `lav_${Math.random().toString(36).substring(2, 34)}`
    
    console.log('Creating profile for user:', userId)
    const { data: insertedData, error: insertError } = await supabaseAdmin
      .from('users')
      .insert({
        id: userId,
        email,
        tier: 'starter',
        api_key: apiKey,
      })
      .select()

    if (insertError) {
      console.error('Error creating profile:', {
        code: insertError.code,
        message: insertError.message,
        details: insertError.details,
        hint: insertError.hint
      })
      return res.status(500).json({ 
        error: 'Failed to create user profile',
        details: insertError.message 
      })
    }

    console.log('Profile created successfully:', insertedData)
    return res.status(200).json({ success: true, apiKey })
  } catch (error: any) {
    console.error('Unexpected error:', error)
    return res.status(500).json({ error: error.message || 'Internal server error' })
  }
}
