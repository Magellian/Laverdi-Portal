import type { NextApiRequest, NextApiResponse } from 'next'
import { stripe } from '@/lib/stripe'
import { createBrowserClient, createAdminClient } from '@/lib/supabase'
import { sendWelcomeEmail, sendReceiptEmail } from '@/lib/email'
import { generateApiKey } from '@/lib/api-key'
import { provisionDroplet } from '@/lib/digitalocean'
import Stripe from 'stripe'

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET

export const config = {
  api: {
    bodyParser: {
      raw: true,
    },
  },
}

async function handleCheckoutSessionCompleted(event: Stripe.Event, supabaseClientParam: any) {
  const session = event.data.object as Stripe.Checkout.Session

  if (!session.customer || !session.metadata) {
    throw new Error('Missing customer or metadata')
  }

  // Get subscription details from Stripe
  const subscription = await stripe.subscriptions.retrieve(
    session.subscription as string
  )

  // Get customer email
  const customer = await stripe.customers.retrieve(session.customer as string)
  if ('deleted' in customer) {
    throw new Error('Customer has been deleted')
  }
  const email = customer.email as string

  // Get plan from metadata
  const plan = (session.metadata as any).plan

  // Find or create user
  const { data: users } = await supabaseClientParam
    .from('users')
    .select('*')
    .eq('email', email)

  let userId = users?.[0]?.id

  if (!userId) {
    // Create new user
    const { data: newUser, error: createError } = await supabaseClientParam
      .from('users')
      .insert({
        email,
        tier: plan,
        api_key: generateApiKey(),
      })
      .select()
      .single()

    if (createError) throw createError
    userId = newUser.id
  } else {
    // Update user tier
    const { error: updateError } = await supabaseClientParam
      .from('users')
      .update({ tier: plan })
      .eq('id', userId)

    if (updateError) throw updateError
  }

  // Create subscription record
  const { error: subError } = await supabaseClientParam.from('subscriptions').insert({
    user_id: userId,
    stripe_subscription_id: subscription.id,
    stripe_customer_id: session.customer as string,
    status: subscription.status,
    current_period_start: new Date(
      subscription.current_period_start * 1000
    ).toISOString(),
    current_period_end: new Date(
      subscription.current_period_end * 1000
    ).toISOString(),
  })

  if (subError) throw subError

  // Get user data
  const { data: userData } = await supabaseClientParam
    .from('users')
    .select('*')
    .eq('id', userId)
    .single()

  // Send welcome email with API key
  await sendWelcomeEmail(email, userData.api_key, plan)

  // Provision DigitalOcean droplet
  try {
    console.log(`Starting DO provisioning for user ${userId}...`);
    await provisionDroplet(userId);
    console.log(`Provisioning started successfully for ${userId}.`);
  } catch (error) {
    console.error(`Error provisioning droplet for user ${userId}:`, error);
    // Note: We don't throw here to avoid failing the whole Stripe webhook, 
    // which would cause Stripe to keep retrying. The user has paid, so we should 
    // handle the provisioning failure asynchronously or via admin intervention.
  }

  // Send receipt email
  if (session.amount_total) {
    const invoiceUrl = subscription.latest_invoice
      ? (typeof subscription.latest_invoice === 'string'
          ? subscription.latest_invoice
          : subscription.latest_invoice.hosted_invoice_url)
      : '#'

    await sendReceiptEmail(
      email,
      plan,
      session.amount_total,
      invoiceUrl as string
    )
  }
}

async function handleCustomerSubscriptionUpdated(event: Stripe.Event, supabaseClientParam: any) {
  const subscription = event.data.object as Stripe.Subscription

  // Update subscription status
  const { error } = await supabaseClientParam
    .from('subscriptions')
    .update({
      status: subscription.status,
      current_period_start: new Date(
        subscription.current_period_start * 1000
      ).toISOString(),
      current_period_end: new Date(
        subscription.current_period_end * 1000
      ).toISOString(),
      cancel_at_period_end: subscription.cancel_at_period_end,
    })
    .eq('stripe_subscription_id', subscription.id)

  if (error) throw error
}

async function handleCustomerSubscriptionDeleted(event: Stripe.Event, supabaseClientParam: any) {
  const subscription = event.data.object as Stripe.Subscription

  // Update subscription as cancelled
  const { error } = await supabaseClientParam
    .from('subscriptions')
    .update({ status: 'canceled' })
    .eq('stripe_subscription_id', subscription.id)

  if (error) throw error
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  let event: Stripe.Event

  try {
    const sig = req.headers['stripe-signature']

    if (!sig || !webhookSecret) {
      return res.status(400).json({ error: 'Missing signature or secret' })
    }

    const body = req.body as Buffer
    event = stripe.webhooks.constructEvent(body, sig, webhookSecret)
  } catch (error: any) {
    console.error('Webhook signature verification failed:', error.message)
    return res.status(400).json({ error: 'Invalid signature' })
  }

  try {
    const supabaseClient = createAdminClient()
    
    switch (event.type) {
      case 'checkout.session.completed':
        await handleCheckoutSessionCompleted(event, supabaseClient)
        break
      case 'customer.subscription.updated':
        await handleCustomerSubscriptionUpdated(event, supabaseClient)
        break
      case 'customer.subscription.deleted':
        await handleCustomerSubscriptionDeleted(event, supabaseClient)
        break
      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return res.status(200).json({ received: true })
  } catch (error: any) {
    console.error('Webhook handler error:', error)
    return res.status(500).json({ error: error.message || 'Internal server error' })
  }
}
