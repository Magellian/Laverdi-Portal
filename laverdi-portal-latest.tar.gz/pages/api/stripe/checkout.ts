import type { NextApiRequest, NextApiResponse } from 'next'
import { stripe, createCheckoutSession, createCustomer } from '@/lib/stripe'
import { createBrowserClient } from '@/lib/supabase'
import { getCurrentUser } from '@/lib/auth'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    // Get current user
    const user = await getCurrentUser()
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized' })
    }

    const { planId } = req.body

    if (!planId) {
      return res.status(400).json({ error: 'Plan ID is required' })
    }

    const supabase = createBrowserClient()

    // Check if user has existing subscription
    const { data: existingSubscription } = await supabase
      .from('subscriptions')
      .select('stripe_customer_id')
      .eq('user_id', user.id)
      .single()

    let customerId = existingSubscription?.stripe_customer_id

    // Create Stripe customer if needed
    if (!customerId) {
      const customer = await createCustomer(user.email!)
      customerId = customer.id
    }

    // Create checkout session
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const session = await createCheckoutSession(
      customerId,
      planId,
      `${appUrl}/checkout/success`
    )

    return res.status(200).json({ sessionId: session.id, url: session.url })
  } catch (error: any) {
    console.error('Checkout error:', error)
    return res
      .status(500)
      .json({ error: error.message || 'Internal server error' })
  }
}
