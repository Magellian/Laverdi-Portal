/**
 * Integration Test Script for Laverdi Portal
 * Tests: Signup → Login → Dashboard → Molty → Rate Limiting
 */

const http = require('http');
const https = require('https');

const BASE_URL = 'http://localhost:3001';
const TEST_EMAIL = 'test-molty@laverdi.local';
const TEST_PASSWORD = 'TestPassword123!';

let cookies = [];
let sessionToken = null;
let testResults = {
  buildStatus: 'PENDING',
  signupFlow: 'PENDING',
  cookiesPresent: false,
  dashboardLoad: 'PENDING',
  moltyRendering: 'PENDING',
  rateLimiting: 'PENDING',
  stripeIntegration: 'PENDING',
  errors: []
};

function request(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(BASE_URL + path);
    const options = {
      method,
      hostname: url.hostname,
      port: url.port || 80,
      path: url.pathname + url.search,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'LaverdiIntegrationTest/1.0'
      }
    };

    if (cookies.length > 0) {
      options.headers['Cookie'] = cookies.join('; ');
    }

    const req = http.request(options, (res) => {
      let data = '';
      
      // Capture Set-Cookie headers
      if (res.headers['set-cookie']) {
        const setCookie = Array.isArray(res.headers['set-cookie']) 
          ? res.headers['set-cookie'] 
          : [res.headers['set-cookie']];
        setCookie.forEach(cookie => {
          const cookieName = cookie.split('=')[0];
          cookies = cookies.filter(c => !c.startsWith(cookieName));
          cookies.push(cookie.split(';')[0]);
        });
      }

      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = data ? JSON.parse(data) : null;
          resolve({ status: res.statusCode, headers: res.headers, data: json });
        } catch (e) {
          resolve({ status: res.statusCode, headers: res.headers, data });
        }
      });
    });

    req.on('error', reject);

    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function testSignup() {
  console.log('\n📝 Testing Signup Flow...');
  try {
    const response = await request('POST', '/api/auth/signup', {
      email: TEST_EMAIL,
      password: TEST_PASSWORD
    });

    if (response.status === 200 || response.status === 201) {
      testResults.signupFlow = 'PASS';
      console.log('✓ Signup successful');
      return true;
    } else {
      testResults.signupFlow = `FAIL (${response.status})`;
      testResults.errors.push(`Signup failed with status ${response.status}`);
      console.log(`✗ Signup failed: ${response.status}`);
      return false;
    }
  } catch (error) {
    testResults.signupFlow = 'ERROR';
    testResults.errors.push(`Signup error: ${error.message}`);
    console.log(`✗ Signup error: ${error.message}`);
    return false;
  }
}

async function testLogin() {
  console.log('\n🔐 Testing Login Flow...');
  try {
    const response = await request('POST', '/api/auth/login', {
      email: TEST_EMAIL,
      password: TEST_PASSWORD
    });

    if (response.status === 200) {
      console.log('✓ Login successful');
      console.log('✓ Auth cookies present:', cookies.filter(c => c.includes('auth')).length > 0);
      testResults.cookiesPresent = cookies.filter(c => c.includes('auth')).length > 0;
      return true;
    } else {
      testResults.errors.push(`Login failed with status ${response.status}`);
      console.log(`✗ Login failed: ${response.status}`);
      return false;
    }
  } catch (error) {
    testResults.errors.push(`Login error: ${error.message}`);
    console.log(`✗ Login error: ${error.message}`);
    return false;
  }
}

async function testDashboard() {
  console.log('\n📊 Testing Dashboard Load...');
  try {
    const response = await request('GET', '/api/admin/stats');

    if (response.status === 200) {
      testResults.dashboardLoad = 'PASS';
      console.log('✓ Dashboard API loaded');
      return true;
    } else if (response.status === 401) {
      console.log('⚠ Authentication required (expected)');
      return true;
    } else {
      testResults.dashboardLoad = `FAIL (${response.status})`;
      testResults.errors.push(`Dashboard load failed: ${response.status}`);
      console.log(`✗ Dashboard load failed: ${response.status}`);
      return false;
    }
  } catch (error) {
    testResults.dashboardLoad = 'ERROR';
    testResults.errors.push(`Dashboard error: ${error.message}`);
    console.log(`✗ Dashboard error: ${error.message}`);
    return false;
  }
}

async function testMoltyRendering() {
  console.log('\n🦑 Testing Molty Character Rendering...');
  try {
    // Check if the page includes the Three.js library and Molty component
    const response = await request('GET', '/');
    
    if (response.status === 200 && response.data) {
      const hasThree = response.data.includes('three') || response.data.includes('THREE');
      const hasMolty = response.data.includes('Molty') || response.data.includes('MoltyCharacter');
      
      if (hasThree && hasMolty) {
        testResults.moltyRendering = 'PASS';
        console.log('✓ Molty component found in page');
        console.log('✓ Three.js library detected');
        return true;
      }
    }
    
    testResults.moltyRendering = 'PASS_RUNTIME'; // Can't verify at static level
    console.log('ℹ Molty rendering requires runtime browser test');
    return true;
  } catch (error) {
    testResults.moltyRendering = 'ERROR';
    testResults.errors.push(`Molty check error: ${error.message}`);
    console.log(`✗ Molty check error: ${error.message}`);
    return false;
  }
}

async function testRateLimiting() {
  console.log('\n⚡ Testing Rate Limiting...');
  try {
    // Make multiple API calls
    let callsCompleted = 0;
    let rateLimitHit = false;
    
    for (let i = 0; i < 5; i++) {
      const response = await request('GET', '/api/admin/stats');
      
      if (response.status === 429) {
        rateLimitHit = true;
        testResults.errors.push('Rate limit triggered (429)');
        break;
      }
      
      if (response.headers['x-ratelimit-remaining']) {
        console.log(`  Call ${i + 1}: Rate limit remaining: ${response.headers['x-ratelimit-remaining']}`);
      }
      
      callsCompleted++;
    }
    
    testResults.rateLimiting = 'PASS';
    console.log(`✓ Made ${callsCompleted} requests without hitting rate limit`);
    return true;
  } catch (error) {
    testResults.rateLimiting = 'ERROR';
    testResults.errors.push(`Rate limiting test error: ${error.message}`);
    console.log(`✗ Rate limiting error: ${error.message}`);
    return false;
  }
}

async function testStripeIntegration() {
  console.log('\n💳 Testing Stripe Integration...');
  try {
    // Check if Stripe key is available
    const response = await request('GET', '/');
    
    if (response.status === 200 && response.data) {
      const hasStripe = response.data.includes('stripe') || response.data.includes('STRIPE');
      
      if (hasStripe) {
        testResults.stripeIntegration = 'PASS';
        console.log('✓ Stripe integration detected');
        return true;
      }
    }
    
    testResults.stripeIntegration = 'PASS_RUNTIME';
    console.log('ℹ Stripe integration requires runtime browser test');
    return true;
  } catch (error) {
    testResults.stripeIntegration = 'ERROR';
    testResults.errors.push(`Stripe check error: ${error.message}`);
    console.log(`✗ Stripe check error: ${error.message}`);
    return false;
  }
}

async function testBuildStatus() {
  console.log('\n🔨 Checking Build Status...');
  try {
    const response = await request('GET', '/');
    
    if (response.status === 200) {
      testResults.buildStatus = 'PASS';
      console.log('✓ Dev server running on port 3001');
      console.log('✓ Home page accessible');
      return true;
    } else {
      testResults.buildStatus = `FAIL (${response.status})`;
      console.log(`✗ Server returned status ${response.status}`);
      return false;
    }
  } catch (error) {
    testResults.buildStatus = 'ERROR';
    testResults.errors.push(`Build status check error: ${error.message}`);
    console.log(`✗ Build status error: ${error.message}`);
    return false;
  }
}

async function runAllTests() {
  console.log('🚀 Starting Laverdi Portal Integration Tests');
  console.log('='.repeat(60));
  
  await testBuildStatus();
  await testMoltyRendering();
  await testRateLimiting();
  await testStripeIntegration();
  
  // Note: Real signup/login requires Supabase
  // These will fail if Supabase is not properly configured
  console.log('\n📋 Test Summary');
  console.log('='.repeat(60));
  console.log(`Build Status:        ${testResults.buildStatus}`);
  console.log(`Signup Flow:         ${testResults.signupFlow}`);
  console.log(`Cookies Present:     ${testResults.cookiesPresent ? 'YES' : 'NO'}`);
  console.log(`Dashboard Load:      ${testResults.dashboardLoad}`);
  console.log(`Molty Rendering:     ${testResults.moltyRendering}`);
  console.log(`Rate Limiting:       ${testResults.rateLimiting}`);
  console.log(`Stripe Integration:  ${testResults.stripeIntegration}`);
  
  if (testResults.errors.length > 0) {
    console.log('\n⚠️  Errors:');
    testResults.errors.forEach(err => console.log(`  - ${err}`));
  }
  
  console.log('\n✅ Automated tests complete. Manual browser testing required for:');
  console.log('  - Signup/Login flow with email verification');
  console.log('  - Cookie presence in DevTools');
  console.log('  - Molty character rendering and animations');
  console.log('  - Zoom behavior and orientation correction');
  console.log('  - Stripe checkout redirect');
  console.log('\n📌 Open http://localhost:3001 in a browser to continue manual testing.');
}

runAllTests().catch(console.error);
