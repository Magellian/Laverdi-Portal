import { type NextRequest, NextResponse } from 'next/server'

/**
 * Middleware for Supabase PKCE auth + secure cookies
 * Automatically refreshes the session on every request.
 * The @supabase/ssr library handles cookie refresh via the updateSession function
 * called from server components and API routes using createServerClient().
 */
export async function middleware(request: NextRequest) {
  try {
    // Session refresh happens automatically in:
    // 1. Server components via createServerClient() 
    // 2. API routes via createServerClient()
    // 3. This middleware passes through while @supabase/ssr cookies lib manages the rest
    
    return NextResponse.next({
      request: {
        headers: request.headers,
      },
    })
  } catch (e) {
    // If there's any error, continue with the request
    console.error('Middleware error:', e)
    return NextResponse.next({
      request: {
        headers: request.headers,
      },
    })
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}
