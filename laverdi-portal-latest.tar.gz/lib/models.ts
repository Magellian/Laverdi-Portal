/**
 * lib/models.ts
 * Model configuration for Laverdi Portal tiers
 * Uses DigitalOcean Gradient AI Platform models via serverless inference
 * 
 * Each tier uses a specific primary model with fallback options
 */

export const MODELS = {
  FREE: {
    primary: "anthropic-claude-haiku-4.5", // DO Gradient model ID: Fast, cheap for free tier
    fallback: "anthropic-claude-haiku-4.5",
    provider: "digitalocean-gradient", // Use DO Gradient API
    maxTokensPerMonth: 150000, // ~100 calls * 1,500 tokens avg
    callsPerMonth: 100,
    description: "Fast, cost-effective model for trial users",
  },
  STARTER: {
    primary: "anthropic-claude-4.6-sonnet", // DO Gradient model ID: Smart, fast
    fallback: "anthropic-claude-haiku-4.5",
    provider: "digitalocean-gradient",
    maxTokensPerMonth: 15000000, // ~10k calls * 1,500 tokens avg
    callsPerMonth: 10000,
    description: "Balanced performance and cost for startups",
  },
  PRO: {
    primary: "anthropic-claude-opus-4.6", // DO Gradient model ID: Most capable
    fallback: "anthropic-claude-4.6-sonnet",
    provider: "digitalocean-gradient",
    maxTokensPerMonth: 150000000, // ~100k calls * 1,500 tokens avg
    callsPerMonth: 100000,
    description: "Most capable model for enterprises",
  },
};

export type TierType = "free" | "starter" | "pro";

export const getTierConfig = (tier: TierType) => {
  const tierUpper = tier.toUpperCase() as keyof typeof MODELS;
  return MODELS[tierUpper];
};

export const getPrimaryModel = (tier: TierType): string => {
  return getTierConfig(tier).primary;
};

export const getFallbackModel = (tier: TierType): string => {
  return getTierConfig(tier).fallback;
};

export const getMonthlyCallLimit = (tier: TierType): number => {
  return getTierConfig(tier).callsPerMonth;
};

export const getMonthlyTokenLimit = (tier: TierType): number => {
  return getTierConfig(tier).maxTokensPerMonth;
};
