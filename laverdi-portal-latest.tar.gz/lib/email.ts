import nodemailer from 'nodemailer'

// Using Nodemailer for email sending (can be switched to SendGrid)
// For production, consider using SendGrid or similar service

let transporter: nodemailer.Transporter | null = null

function getTransporter() {
  if (transporter) return transporter

  const sendgridApiKey = process.env.SENDGRID_API_KEY

  if (sendgridApiKey) {
    // Using SendGrid via Nodemailer
    transporter = nodemailer.createTransport({
      host: 'smtp.sendgrid.net',
      port: 587,
      auth: {
        user: 'apikey',
        pass: sendgridApiKey,
      },
    })
  } else {
    // Fallback to SMTP configuration
    const smtpHost = process.env.SMTP_HOST
    const smtpPort = parseInt(process.env.SMTP_PORT || '587')
    const smtpUser = process.env.SMTP_USER
    const smtpPass = process.env.SMTP_PASS

    if (!smtpHost || !smtpUser || !smtpPass) {
      console.warn(
        'Email service not configured. Please set SENDGRID_API_KEY or SMTP_* variables.'
      )
      return null
    }

    transporter = nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: smtpPort === 465,
      auth: {
        user: smtpUser,
        pass: smtpPass,
      },
    })
  }

  return transporter
}

export async function sendEmail(options: {
  to: string
  subject: string
  html: string
  text?: string
}) {
  const transporter = getTransporter()
  if (!transporter) {
    console.error('Email transporter not configured')
    throw new Error('Email service not available')
  }

  const fromEmail = process.env.SENDGRID_FROM_EMAIL || 'noreply@laverdi.tech'

  try {
    await transporter.sendMail({
      from: fromEmail,
      to: options.to,
      subject: options.subject,
      html: options.html,
      text: options.text,
    })
    console.log(`Email sent to ${options.to}`)
  } catch (error) {
    console.error('Failed to send email:', error)
    throw error
  }
}

export async function sendWelcomeEmail(
  email: string,
  apiKey: string,
  tier: string
) {
  const transporter = getTransporter()
  if (!transporter) {
    console.error('Email transporter not configured')
    return
  }

  const fromEmail = process.env.SENDGRID_FROM_EMAIL || 'noreply@laverdi.tech'

  const htmlContent = `
    <h2>Welcome to Laverdi.tech OpenClaw</h2>
    <p>Thank you for signing up for the <strong>${tier}</strong> plan!</p>
    
    <h3>Your API Key</h3>
    <p><code>${apiKey}</code></p>
    <p style="color: #666; font-size: 12px;">Keep this API key secure. Do not share it with anyone.</p>
    
    <h3>Getting Started</h3>
    <p>Visit your dashboard to:</p>
    <ul>
      <li>View API usage and analytics</li>
      <li>Manage multiple API keys</li>
      <li>Update subscription settings</li>
      <li>Access documentation</li>
    </ul>
    
    <p>Questions? Contact us at support@laverdi.tech</p>
  `

  try {
    await transporter.sendMail({
      from: fromEmail,
      to: email,
      subject: 'Welcome to Laverdi.tech OpenClaw - Your API Key',
      html: htmlContent,
    })
    console.log(`Welcome email sent to ${email}`)
  } catch (error) {
    console.error('Failed to send welcome email:', error)
    throw error
  }
}

export async function sendReceiptEmail(
  email: string,
  planName: string,
  amount: number,
  invoiceUrl: string
) {
  const transporter = getTransporter()
  if (!transporter) {
    console.error('Email transporter not configured')
    return
  }

  const fromEmail = process.env.SENDGRID_FROM_EMAIL || 'noreply@laverdi.tech'

  const htmlContent = `
    <h2>Payment Confirmation</h2>
    <p>Thank you for your payment!</p>
    
    <table style="width: 100%; border-collapse: collapse;">
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 8px; font-weight: bold;">Plan</td>
        <td style="padding: 8px;">${planName}</td>
      </tr>
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 8px; font-weight: bold;">Amount</td>
        <td style="padding: 8px;">$${(amount / 100).toFixed(2)}</td>
      </tr>
    </table>
    
    <p style="margin-top: 20px;">
      <a href="${invoiceUrl}" style="background-color: #3B82F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
        View Invoice
      </a>
    </p>
  `

  try {
    await transporter.sendMail({
      from: fromEmail,
      to: email,
      subject: 'Payment Confirmation - Laverdi.tech OpenClaw',
      html: htmlContent,
    })
    console.log(`Receipt email sent to ${email}`)
  } catch (error) {
    console.error('Failed to send receipt email:', error)
  }
}

// ---------------------------------------------------------------------------
// Free-trial lifecycle email stubs
// These log to console now. Hook up real sends in a future sprint.
// ---------------------------------------------------------------------------

/**
 * Day-7 trial reminder.
 * Called by a scheduled job 7 days after trial_started_at.
 */
export async function sendTrialReminderEmail(
  email: string,
  daysLeft: number
): Promise<void> {
  // TODO: send real email — subject "Your Laverdi trial ends in X days"
  console.log(`[EMAIL STUB] sendTrialReminderEmail → ${email} (${daysLeft} days left)`)
}

/**
 * Day-15 (trial expiry) email.
 * Called by a scheduled job when trial_expires_at is reached.
 */
export async function sendTrialExpiringEmail(email: string): Promise<void> {
  // TODO: send real email — subject "Your Laverdi trial has expired"
  console.log(`[EMAIL STUB] sendTrialExpiringEmail → ${email}`)
}

/**
 * Upgrade prompt sent when a user hits or approaches their call limit.
 */
export async function sendUpgradePromptEmail(email: string): Promise<void> {
  // TODO: send real email — subject "You've reached your Laverdi call limit"
  console.log(`[EMAIL STUB] sendUpgradePromptEmail → ${email}`)
}

// ---------------------------------------------------------------------------

export async function sendInstanceReadyEmail(
  email: string,
  ipAddress: string
) {
  const transporter = getTransporter()
  if (!transporter) {
    console.error('Email transporter not configured')
    return
  }

  const fromEmail = process.env.SENDGRID_FROM_EMAIL || 'noreply@laverdi.tech'

  const htmlContent = `
    <h2>Your OpenClaw Instance is Ready!</h2>
    <p>Great news! Your dedicated OpenClaw instance has been successfully provisioned and is now online.</p>
    
    <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
      <h3 style="margin-top: 0;">Instance Details</h3>
      <p style="margin-bottom: 5px;"><strong>IP Address:</strong> <code>${ipAddress}</code></p>
    </div>
    
    <h3>Next Steps</h3>
    <ol>
      <li>Open your local OpenClaw app</li>
      <li>Go to the <strong>Connect</strong> tab</li>
      <li>Select <strong>Remote VPS</strong></li>
      <li>Enter your instance IP address: <code>${ipAddress}</code></li>
    </ol>
    
    <p>If you have any questions or need help connecting, reply to this email or contact us at support@laverdi.tech</p>
  `

  try {
    await transporter.sendMail({
      from: fromEmail,
      to: email,
      subject: '🚀 Your OpenClaw Instance is Ready',
      html: htmlContent,
    })
    console.log(`Instance ready email sent to ${email}`)
  } catch (error) {
    console.error('Failed to send instance ready email:', error)
  }
}
