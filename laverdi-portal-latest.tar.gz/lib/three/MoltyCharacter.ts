/**
 * MoltyCharacter.ts
 * Production-ready Molty character with orientation constraints
 * - Stays upright (Y-axis locked)
 * - Faces camera (Z-axis rotation only)
 * - Smooth quaternion-based rotation
 * - Preserved leg geometry and proportions
 * - Full backward compatibility with all old methods
 */

import * as THREE from 'three';

export interface MoltyConfig {
  scale?: number;
  headRadius?: number;
  bodyHeight?: number;
  positionY?: number;
  rotationSpeed?: number;
}

export class MoltyCharacter extends THREE.Group {
  private head: THREE.Mesh;
  private body: THREE.Mesh;
  private leftLeg: THREE.Mesh;
  private rightLeg: THREE.Mesh;
  private targetQuaternion: THREE.Quaternion;
  private currentQuaternion: THREE.Quaternion;
  private rotationSpeed: number = 0.08;
  
  // Glow & materials for lighting effects
  private bodyMaterial: THREE.MeshPhongMaterial;
  private headMaterial: THREE.MeshPhongMaterial;
  private legMaterial: THREE.MeshPhongMaterial;
  private glowIntensity: number = 0.5;
  private light: THREE.PointLight;
  
  // Animation state
  private isDisposed: boolean = false;
  private isAutoCorrectingOrientation: boolean = false;
  private autoCorrectSpeed: number = 3.0;
  private cameraPosition: THREE.Vector3 = new THREE.Vector3(0, 0, 4);

  constructor(config: MoltyConfig = {}) {
    super();
    
    const {
      scale = 1,
      headRadius = 0.5 * scale,
      bodyHeight = 1.2 * scale,
      positionY = 0,
      rotationSpeed = 0.08,
    } = config;

    this.rotationSpeed = rotationSpeed;
    this.targetQuaternion = new THREE.Quaternion();
    this.currentQuaternion = this.quaternion.clone();

    // Build materials with emissive properties for glow
    this.bodyMaterial = new THREE.MeshPhongMaterial({
      color: 0xff3333,
      emissive: 0xff3333,
      emissiveIntensity: this.glowIntensity,
      shininess: 100,
    });

    this.headMaterial = new THREE.MeshPhongMaterial({
      color: 0xff4444,
      emissive: 0xff4444,
      emissiveIntensity: this.glowIntensity,
      shininess: 100,
    });

    this.legMaterial = new THREE.MeshPhongMaterial({
      color: 0xcc2222,
      emissive: 0xcc2222,
      emissiveIntensity: this.glowIntensity * 0.6,
      shininess: 80,
    });

    // Build character geometry
    this.head = this.createHead(headRadius);
    this.body = this.createBody(bodyHeight, scale);
    this.leftLeg = this.createLeg(scale, -0.25 * scale);
    this.rightLeg = this.createLeg(scale, 0.25 * scale);

    // Position legs (stay at bottom, fixed)
    this.leftLeg.position.set(-0.25 * scale, -bodyHeight / 2 - 0.3 * scale, 0);
    this.rightLeg.position.set(0.25 * scale, -bodyHeight / 2 - 0.3 * scale, 0);

    // Add to group
    this.add(this.head);
    this.add(this.body);
    this.add(this.leftLeg);
    this.add(this.rightLeg);

    // Create red point light for glow effect
    this.light = new THREE.PointLight(0xff0000, 50, 10);
    this.light.position.set(0, 0, 1);
    this.add(this.light);

    // Position group
    this.position.y = positionY;
    this.rotation.order = 'YXZ';
  }

  /**
   * Create head geometry
   */
  private createHead(radius: number): THREE.Mesh {
    const geometry = new THREE.SphereGeometry(radius, 32, 32);
    const head = new THREE.Mesh(geometry, this.headMaterial);
    head.position.y = 0.7;
    head.castShadow = true;
    head.receiveShadow = true;
    return head;
  }

  /**
   * Create body geometry
   */
  private createBody(height: number, scale: number): THREE.Mesh {
    const geometry = new THREE.CylinderGeometry(0.35 * scale, 0.4 * scale, height, 32);
    const body = new THREE.Mesh(geometry, this.bodyMaterial);
    body.castShadow = true;
    body.receiveShadow = true;
    return body;
  }

  /**
   * Create leg geometry (fixed position, no animation)
   */
  private createLeg(scale: number, offsetX: number): THREE.Mesh {
    const geometry = new THREE.CylinderGeometry(0.1 * scale, 0.12 * scale, 0.5 * scale, 16);
    const leg = new THREE.Mesh(geometry, this.legMaterial);
    leg.castShadow = true;
    leg.receiveShadow = true;
    return leg;
  }

  /**
   * Constrain orientation to upright
   * 
   * Locks Y-axis rotation, allows Z-axis only (face camera)
   * Ensures character always stands on feet
   */
  public constrainOrientationToUpright(): void {
    // Extract current euler angles
    const euler = new THREE.Euler();
    euler.setFromQuaternion(this.currentQuaternion, 'YXZ');

    // Zero out X and Y rotations (keep upright)
    // Only preserve Z rotation (face camera)
    const constrainedEuler = new THREE.Euler(0, 0, euler.z, 'YXZ');
    const constrainedQuat = new THREE.Quaternion();
    constrainedQuat.setFromEuler(constrainedEuler);

    this.targetQuaternion.copy(constrainedQuat);
  }

  /**
   * Smooth quaternion rotation toward target
   * Interpolates between current and target rotation
   */
  public smoothRotateTowardTarget(): void {
    this.currentQuaternion.slerp(this.targetQuaternion, this.rotationSpeed);
    this.quaternion.copy(this.currentQuaternion);
  }

  /**
   * Face camera with smooth Z-axis rotation
   * Calculates angle to face camera, constrains to Z-axis only
   */
  public faceCamera(cameraPosition: THREE.Vector3): void {
    // Calculate direction to camera
    const directionToCamera = cameraPosition.clone().sub(this.position).normalize();

    // Create look-at quaternion
    const lookAtQuat = new THREE.Quaternion();
    const upVector = new THREE.Vector3(0, 1, 0);
    
    // Use forward vector (0, 0, 1) and calculate rotation to face camera
    const forward = new THREE.Vector3(0, 0, 1);
    const axis = new THREE.Vector3();
    axis.crossVectors(forward, directionToCamera).normalize();

    if (axis.lengthSq() > 0.001) {
      const angle = Math.acos(Math.max(-1, Math.min(1, forward.dot(directionToCamera))));
      lookAtQuat.setFromAxisAngle(axis, angle);
    }

    // Constrain to Z-axis rotation only
    const euler = new THREE.Euler();
    euler.setFromQuaternion(lookAtQuat, 'YXZ');
    
    const constrainedEuler = new THREE.Euler(0, 0, euler.z, 'YXZ');
    this.targetQuaternion.setFromEuler(constrainedEuler);

    this.constrainOrientationToUpright();
    this.smoothRotateTowardTarget();
  }

  /**
   * Set target rotation on Z-axis only
   * @param angleZ Rotation in radians around Z-axis
   */
  public setZAxisRotation(angleZ: number): void {
    const euler = new THREE.Euler(0, 0, angleZ, 'YXZ');
    this.targetQuaternion.setFromEuler(euler);
    this.constrainOrientationToUpright();
  }

  /**
   * Update character (call in animation loop)
   */
  public update(): void {
    this.smoothRotateTowardTarget();
  }

  /**
   * Get current rotation (for debugging/monitoring)
   */
  public getRotationEuler(): THREE.Euler {
    const euler = new THREE.Euler();
    euler.setFromQuaternion(this.currentQuaternion, 'YXZ');
    return euler;
  }

  /**
   * Check if character is upright (Y-axis near zero)
   */
  public isUpright(): boolean {
    const euler = this.getRotationEuler();
    return Math.abs(euler.x) < 0.1 && Math.abs(euler.y) < 0.1;
  }

  /**
   * Set glow intensity for all emissive materials
   * @param intensity Glow intensity (0-1)
   */
  public setGlowIntensity(intensity: number): void {
    this.glowIntensity = Math.max(0, Math.min(1, intensity));
    this.bodyMaterial.emissiveIntensity = this.glowIntensity;
    this.headMaterial.emissiveIntensity = this.glowIntensity;
    this.legMaterial.emissiveIntensity = this.glowIntensity * 0.6;
    this.light.intensity = 50 + intensity * 100;
  }

  /**
   * Auto-correct orientation to face camera
   * Smoothly rotates to face forward
   */
  public autoCorrectOrientation(): void {
    if (this.isAutoCorrectingOrientation) return;
    
    this.isAutoCorrectingOrientation = true;
    const euler = new THREE.Euler(0, 0, 0, 'YXZ');
    this.targetQuaternion.setFromEuler(euler);
  }

  /**
   * Update camera position for tracking
   * @param position Camera position in world space
   */
  public setCameraPosition(position: THREE.Vector3): void {
    this.cameraPosition.copy(position);
  }

  /**
   * Animate method called each frame
   * @param deltaTime Time since last frame in seconds
   */
  public animate(deltaTime: number): void {
    if (this.isDisposed) return;

    // Smooth quaternion interpolation for auto-correct
    if (this.isAutoCorrectingOrientation) {
      const lerpFactor = Math.min(1, deltaTime * this.autoCorrectSpeed);
      this.currentQuaternion.slerpQuaternions(
        this.currentQuaternion,
        this.targetQuaternion,
        lerpFactor
      );
      this.quaternion.copy(this.currentQuaternion);

      // Check if we're close enough to target
      if (this.currentQuaternion.angleTo(this.targetQuaternion) < 0.01) {
        this.isAutoCorrectingOrientation = false;
      }
    }

    // Subtle idle animations
    const time = Date.now() * 0.001;

    // Bob up and down slightly
    this.position.y += Math.sin(time * 0.8) * 0.02;

    // Gentle sway side to side
    this.rotation.z = Math.sin(time * 0.5) * 0.03;
  }

  /**
   * Dispose of all resources
   */
  public dispose(): void {
    if (this.isDisposed) return;

    this.isDisposed = true;

    // Dispose geometries
    if (this.head && this.head.geometry) {
      this.head.geometry.dispose();
    }
    if (this.body && this.body.geometry) {
      this.body.geometry.dispose();
    }
    if (this.leftLeg && this.leftLeg.geometry) {
      this.leftLeg.geometry.dispose();
    }
    if (this.rightLeg && this.rightLeg.geometry) {
      this.rightLeg.geometry.dispose();
    }

    // Dispose materials
    this.bodyMaterial?.dispose();
    this.headMaterial?.dispose();
    this.legMaterial?.dispose();

    // Remove from parent
    if (this.parent) {
      this.parent.remove(this);
    }
  }

  /**
   * Get the THREE.Group for scene integration
   * @returns The group containing all geometry
   */
  public getGroup(): THREE.Group {
    return this;
  }
}

// Factory function for backward compatibility (old API)
export function createMoltyCharacter(
  configOrScene: MoltyConfig | THREE.Scene = {}
): MoltyCharacter | { molty: MoltyCharacter; animate: (deltaTime: number) => void; setGlow: (intensity: number) => void; dispose: () => void } {
  // Check if argument is a Scene (old API) or config object (new API)
  const isScene = configOrScene instanceof THREE.Scene;
  
  if (isScene) {
    // Old API: createMoltyCharacter(scene)
    const molty = new MoltyCharacter();
    (configOrScene as THREE.Scene).add(molty);

    return {
      molty,
      animate: (deltaTime: number) => molty.animate(deltaTime),
      setGlow: (intensity: number) => molty.setGlowIntensity(intensity),
      dispose: () => molty.dispose(),
    };
  } else {
    // New API: createMoltyCharacter(config)
    return new MoltyCharacter(configOrScene as MoltyConfig);
  }
}

export default MoltyCharacter;
