import * as THREE from 'three'

export class MoltyCharacter {
  scene: THREE.Scene
  group: THREE.Group
  bodyMesh: THREE.Mesh
  headMesh: THREE.Mesh
  leftLegMesh: THREE.Mesh
  rightLegMesh: THREE.Mesh
  leftArmMesh: THREE.Mesh
  rightArmMesh: THREE.Mesh
  leftEyeMesh: THREE.Mesh
  rightEyeMesh: THREE.Mesh
  
  light: THREE.PointLight
  rotationSpeed = 0.001
  isDisposed = false
  glowIntensity = 0.5
  
  // Material references
  bodyMaterial: THREE.MeshStandardMaterial
  headMaterial: THREE.MeshStandardMaterial
  limMaterial: THREE.MeshStandardMaterial
  eyeMaterial: THREE.MeshStandardMaterial
  
  // Orientation tracking
  targetRotation = new THREE.Quaternion()
  currentRotation = new THREE.Quaternion()
  isAutoCorrectingOrientation = false
  autoCorrectSpeed = 3.0 // Smooth rotation speed (0.5-1 sec for noticeable movement)
  
  // Camera tracking for engagement
  cameraPosition = new THREE.Vector3(0, 0, 4)

  constructor(scene: THREE.Scene) {
    this.scene = scene
    this.group = new THREE.Group()

    // Material definitions
    this.bodyMaterial = new THREE.MeshStandardMaterial({
      color: 0xff3333,
      roughness: 0.2,
      metalness: 0.8,
      emissive: 0xff3333,
      emissiveIntensity: this.glowIntensity
    })

    this.headMaterial = new THREE.MeshStandardMaterial({
      color: 0xff4444,
      roughness: 0.15,
      metalness: 0.9,
      emissive: 0xff4444,
      emissiveIntensity: this.glowIntensity
    })

    this.limMaterial = new THREE.MeshStandardMaterial({
      color: 0xcc2222,
      roughness: 0.3,
      metalness: 0.7,
      emissive: 0xcc2222,
      emissiveIntensity: this.glowIntensity * 0.6
    })

    this.eyeMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.1,
      metalness: 0.5,
      emissive: 0xffffff,
      emissiveIntensity: this.glowIntensity
    })

    // Body - sphere (0.6 units tall)
    const bodyGeometry = new THREE.IcosahedronGeometry(0.35, 4)
    this.bodyMesh = new THREE.Mesh(bodyGeometry, this.bodyMaterial)
    this.bodyMesh.position.y = 0.3
    this.bodyMesh.castShadow = true
    this.group.add(this.bodyMesh)

    // Head - sphere (0.5 units diameter) positioned above body
    const headGeometry = new THREE.IcosahedronGeometry(0.25, 4)
    this.headMesh = new THREE.Mesh(headGeometry, this.headMaterial)
    this.headMesh.position.set(0, 0.75, 0)
    this.headMesh.castShadow = true
    this.group.add(this.headMesh)

    // Left Eye (tiny sphere)
    const eyeGeometry = new THREE.SphereGeometry(0.08, 8, 8)
    this.leftEyeMesh = new THREE.Mesh(eyeGeometry, this.eyeMaterial)
    this.leftEyeMesh.position.set(-0.12, 0.8, 0.22)
    this.group.add(this.leftEyeMesh)

    // Right Eye
    this.rightEyeMesh = new THREE.Mesh(eyeGeometry, this.eyeMaterial)
    this.rightEyeMesh.position.set(0.12, 0.8, 0.22)
    this.group.add(this.rightEyeMesh)

    // Left Leg - STUMPY (0.35 units long)
    const legGeometry = new THREE.CapsuleGeometry(0.08, 0.35, 4, 8)
    this.leftLegMesh = new THREE.Mesh(legGeometry, this.limMaterial)
    this.leftLegMesh.position.set(-0.15, -0.25, 0)
    this.leftLegMesh.castShadow = true
    this.group.add(this.leftLegMesh)

    // Right Leg - STUMPY
    this.rightLegMesh = new THREE.Mesh(legGeometry, this.limMaterial)
    this.rightLegMesh.position.set(0.15, -0.25, 0)
    this.rightLegMesh.castShadow = true
    this.group.add(this.rightLegMesh)

    // Left Arm - no claw
    const armGeometry = new THREE.CapsuleGeometry(0.07, 0.45, 4, 8)
    this.leftArmMesh = new THREE.Mesh(armGeometry, this.limMaterial)
    this.leftArmMesh.position.set(-0.45, 0.4, 0)
    this.leftArmMesh.rotation.z = 0.3
    this.leftArmMesh.castShadow = true
    this.group.add(this.leftArmMesh)

    // Right Arm - no claw
    this.rightArmMesh = new THREE.Mesh(armGeometry, this.limMaterial)
    this.rightArmMesh.position.set(0.45, 0.4, 0)
    this.rightArmMesh.rotation.z = -0.3
    this.rightArmMesh.castShadow = true
    this.group.add(this.rightArmMesh)

    // Create red point light for chiaroscuro effect
    this.light = new THREE.PointLight(0xff0000, 50, 10)
    this.light.position.set(0, 0, 1)
    this.group.add(this.light)

    // Position Molty in scene - slightly to the right for close-up zoom
    this.group.position.set(0.5, 0, 0)
    this.group.rotation.order = 'YXZ' // Important for proper orientation control
    
    // Set initial target rotation (facing forward)
    const euler = new THREE.Euler(0, 0, 0, 'YXZ')
    this.targetRotation.setFromEuler(euler)
    this.currentRotation.copy(this.targetRotation)
    
    this.scene.add(this.group)
  }

  /**
   * Set glow intensity for all emissive materials
   */
  setGlowIntensity(intensity: number) {
    this.glowIntensity = Math.max(0, Math.min(1, intensity))
    this.bodyMaterial.emissiveIntensity = this.glowIntensity
    this.headMaterial.emissiveIntensity = this.glowIntensity
    this.limMaterial.emissiveIntensity = this.glowIntensity * 0.6
    this.eyeMaterial.emissiveIntensity = this.glowIntensity
    this.light.intensity = 50 + intensity * 100
  }

  /**
   * Auto-correct orientation to face camera
   * Called when zoomed in to make Molty face the user directly
   */
  autoCorrectOrientation() {
    if (this.isAutoCorrectingOrientation) return
    
    this.isAutoCorrectingOrientation = true
    
    // Target: Face forward toward camera (0, 0, 0)
    const euler = new THREE.Euler(0, 0, 0, 'YXZ')
    this.targetRotation.setFromEuler(euler)
  }

  /**
   * Update camera position for tracking eye engagement
   */
  setCameraPosition(position: THREE.Vector3) {
    this.cameraPosition.copy(position)
  }

  /**
   * Animate method called each frame
   */
  animate(deltaTime: number) {
    if (this.isDisposed) return

    // Smooth quaternion interpolation for auto-correct
    if (this.isAutoCorrectingOrientation) {
      const lerpFactor = Math.min(1, deltaTime * this.autoCorrectSpeed)
      this.currentRotation.slerpQuaternions(
        this.currentRotation,
        this.targetRotation,
        lerpFactor
      )
      this.group.quaternion.copy(this.currentRotation)

      // Check if we're close enough to target
      if (this.currentRotation.angleTo(this.targetRotation) < 0.01) {
        this.isAutoCorrectingOrientation = false
      }
    }

    // Subtle idle animations
    const time = Date.now() * 0.001

    // Bob up and down slightly
    this.group.position.y = Math.sin(time * 0.8) * 0.05

    // Gentle sway side to side
    this.group.rotation.z = Math.sin(time * 0.5) * 0.03

    // Arm wave animation
    const armWave = Math.sin(time * 1.5) * 0.15
    this.leftArmMesh.rotation.z = 0.3 + armWave
    this.rightArmMesh.rotation.z = -0.3 - armWave

    // Eyes follow camera (subtle tracking)
    const eyeOffsetX = Math.sin(time * 0.7) * 0.05
    const eyeOffsetZ = Math.cos(time * 0.7) * 0.03
    
    this.leftEyeMesh.position.x = -0.12 + eyeOffsetX
    this.leftEyeMesh.position.z = 0.22 + eyeOffsetZ
    
    this.rightEyeMesh.position.x = 0.12 + eyeOffsetX
    this.rightEyeMesh.position.z = 0.22 + eyeOffsetZ

    // Gentle head tilt
    this.headMesh.rotation.x = Math.sin(time * 0.6) * 0.05
    this.headMesh.rotation.z = Math.sin(time * 0.4) * 0.03
  }

  dispose() {
    if (this.isDisposed) return

    this.isDisposed = true

    // Dispose all geometries and materials
    ;[this.bodyMesh, this.headMesh, this.leftLegMesh, this.rightLegMesh, this.leftArmMesh, this.rightArmMesh, this.leftEyeMesh, this.rightEyeMesh].forEach(mesh => {
      mesh.geometry?.dispose()
    })

    this.bodyMaterial?.dispose()
    this.headMaterial?.dispose()
    this.limMaterial?.dispose()
    this.eyeMaterial?.dispose()

    // Remove from scene
    this.scene.remove(this.group)
  }

  getGroup(): THREE.Group {
    return this.group
  }
}

export function createMoltyCharacter(scene: THREE.Scene): {
  molty: MoltyCharacter
  animate: (deltaTime: number) => void
  setGlow: (intensity: number) => void
  dispose: () => void
} {
  const molty = new MoltyCharacter(scene)

  return {
    molty,
    animate: (deltaTime: number) => molty.animate(deltaTime),
    setGlow: (intensity: number) => molty.setGlowIntensity(intensity),
    dispose: () => molty.dispose()
  }
}
