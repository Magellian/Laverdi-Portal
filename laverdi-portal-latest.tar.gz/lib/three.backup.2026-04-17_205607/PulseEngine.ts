import * as THREE from 'three'
import { PulseConfig } from './types'

interface PulseRing {
  mesh: THREE.Mesh
  speedX: number
  speedY: number
  opacityPhase: number
}

export class PulseEngineScene {
  scene: THREE.Scene
  camera: THREE.PerspectiveCamera
  renderer: THREE.WebGLRenderer
  canvas: HTMLCanvasElement
  pulses: PulseRing[] = []
  mesh: THREE.Mesh
  animationId: number | null = null
  isDisposed = false
  pulseGroup: THREE.Group

  constructor(canvas: HTMLCanvasElement, config?: Partial<PulseConfig>) {
    this.canvas = canvas
    const width = config?.width || window.innerWidth
    const height = config?.height || window.innerHeight
    const antialias = config?.antialias !== false

    // Scene setup
    this.scene = new THREE.Scene()
    this.scene.background = new THREE.Color(0x000000)
    this.scene.fog = new THREE.FogExp2(0x000000, 0.15)

    // Camera setup
    this.camera = new THREE.PerspectiveCamera(
      75,
      width / height,
      0.1,
      1000
    )
    this.camera.position.z = 5

    // Renderer setup
    this.renderer = new THREE.WebGLRenderer({ 
      canvas, 
      antialias,
      alpha: true
    })
    this.renderer.setSize(width, height)
    this.renderer.setPixelRatio(window.devicePixelRatio)

    // Lighting - Lobster Red (#ff0000)
    const lobsterLight = new THREE.PointLight(0xff0000, 100, 20)
    lobsterLight.position.set(2, 2, 2)
    this.scene.add(lobsterLight)

    // Ambient light for subtle fill
    const ambientLight = new THREE.AmbientLight(0xff0000, 0.05)
    this.scene.add(ambientLight)

    // Central TorusKnot object with metallic material
    const geometry = new THREE.TorusKnotGeometry(1, 0.3, 200, 32)
    const material = new THREE.MeshStandardMaterial({
      color: 0x222222,
      roughness: 0.1,
      metalness: 0.9,
      emissive: 0xff0000,
      emissiveIntensity: 0.05
    })
    this.mesh = new THREE.Mesh(geometry, material)
    this.scene.add(this.mesh)

    // Create 8 rotating torus rings (different sizes, opacity)
    this.pulseGroup = new THREE.Group()
    const pulseCount = config?.pulseCount || 8

    for (let i = 0; i < pulseCount; i++) {
      const pGeometry = new THREE.TorusGeometry(2 + (i * 0.2), 0.01, 16, 100)
      const pMaterial = new THREE.MeshBasicMaterial({
        color: 0xff0000,
        transparent: true,
        opacity: 0.3
      })
      const pMesh = new THREE.Mesh(pGeometry, pMaterial)
      pMesh.rotation.x = Math.random() * Math.PI
      pMesh.rotation.y = Math.random() * Math.PI
      this.pulseGroup.add(pMesh)

      this.pulses.push({
        mesh: pMesh,
        speedX: (Math.random() - 0.5) * 0.01,
        speedY: (Math.random() - 0.5) * 0.01,
        opacityPhase: Math.random() * Math.PI * 2
      })
    }
    this.scene.add(this.pulseGroup)

    // Handle window resize
    this.onWindowResize = this.onWindowResize.bind(this)
    window.addEventListener('resize', this.onWindowResize)
  }

  animate(time: number) {
    if (this.isDisposed) return

    // Rotate main object
    this.mesh.rotation.x += 0.005
    this.mesh.rotation.y += 0.005

    // Animate pulse tendrils
    this.pulses.forEach((p) => {
      p.mesh.rotation.x += p.speedX
      p.mesh.rotation.y += p.speedY

      // Pulsing opacity
      p.opacityPhase += 0.02
      const material = p.mesh.material as THREE.MeshBasicMaterial
      material.opacity = 0.1 + Math.sin(p.opacityPhase) * 0.2
    })

    // Render scene
    this.renderer.render(this.scene, this.camera)
  }

  onWindowResize() {
    if (this.isDisposed) return

    const width = window.innerWidth
    const height = window.innerHeight

    this.camera.aspect = width / height
    this.camera.updateProjectionMatrix()
    this.renderer.setSize(width, height)
  }

  dispose() {
    if (this.isDisposed) return

    this.isDisposed = true
    window.removeEventListener('resize', this.onWindowResize)

    // Dispose geometries and materials
    this.scene.traverse((object) => {
      if (object instanceof THREE.Mesh) {
        object.geometry?.dispose()
        if (Array.isArray(object.material)) {
          object.material.forEach((m) => m.dispose())
        } else {
          object.material?.dispose()
        }
      }
    })

    this.renderer.dispose()
  }
}

export function initPulseEngine(
  canvas: HTMLCanvasElement,
  config?: Partial<PulseConfig>
): {
  scene: PulseEngineScene
  animate: (time: number) => void
  dispose: () => void
} {
  const scene = new PulseEngineScene(canvas, config)

  return {
    scene,
    animate: (time: number) => scene.animate(time),
    dispose: () => scene.dispose()
  }
}
