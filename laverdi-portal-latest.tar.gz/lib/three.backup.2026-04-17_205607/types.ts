// TypeScript interfaces for Three.js scenes and animations

export interface AnimationConfig {
  duration: number
  fps?: number
  easing?: 'linear' | 'easeIn' | 'easeOut' | 'easeInOut'
}

export interface ParticleConfig {
  count: number
  speed: number
  size: number
  color: string | number
}

export interface SceneConfig {
  width: number
  height: number
  antialias?: boolean
}

export interface PulseConfig extends SceneConfig {
  pulseCount?: number
  meshColor?: number
  lightColor?: number
  lightIntensity?: number
  ambientIntensity?: number
}

export interface ParticleSystemConfig extends SceneConfig {
  particleCount?: number
  blending?: 'additive' | 'normal'
  opacity?: number
}
