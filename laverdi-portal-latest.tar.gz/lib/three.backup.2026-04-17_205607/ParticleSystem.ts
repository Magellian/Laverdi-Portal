import * as THREE from 'three'
import { ParticleSystemConfig } from './types'

export class ParticleSystemScene {
  scene: THREE.Scene
  camera: THREE.PerspectiveCamera
  renderer: THREE.WebGLRenderer
  canvas: HTMLCanvasElement
  points: THREE.Points
  positions: Float32Array
  velocities: Float32Array
  originalPositions: Float32Array
  animationId: number | null = null
  isAnimating = false
  particleCount: number
  emergenceStartTime: number | null = null
  emergenceDuration: number | null = null
  onCompleteCallback: (() => void) | null = null
  isDisposed = false
  lastTime = performance.now()

  constructor(canvas: HTMLCanvasElement, config?: Partial<ParticleSystemConfig>) {
    this.canvas = canvas
    const width = config?.width || window.innerWidth
    const height = config?.height || window.innerHeight
    const antialias = config?.antialias !== false
    this.particleCount = config?.particleCount || 2500

    // Scene setup
    this.scene = new THREE.Scene()
    this.scene.background = new THREE.Color(0x000000)

    // Camera setup
    this.camera = new THREE.PerspectiveCamera(
      75,
      width / height,
      0.1,
      1000
    )
    this.camera.position.z = 8

    // Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias,
      alpha: true
    })
    this.renderer.setSize(width, height)
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

    // Initialize particle arrays
    this.positions = new Float32Array(this.particleCount * 3)
    this.velocities = new Float32Array(this.particleCount * 3)
    this.originalPositions = new Float32Array(this.particleCount * 3)

    // Populate particles in sphere distribution
    for (let i = 0; i < this.particleCount; i++) {
      const r = 3 + Math.random() * 2
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)

      // Store original sphere positions
      this.positions[i * 3] = r * Math.sin(phi) * Math.cos(theta)
      this.positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta)
      this.positions[i * 3 + 2] = r * Math.cos(phi)

      this.originalPositions[i * 3] = this.positions[i * 3]
      this.originalPositions[i * 3 + 1] = this.positions[i * 3 + 1]
      this.originalPositions[i * 3 + 2] = this.positions[i * 3 + 2]

      // Initialize velocities
      this.velocities[i * 3] = (Math.random() - 0.5) * 0.02
      this.velocities[i * 3 + 1] = (Math.random() - 0.5) * 0.02
      this.velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.02
    }

    // Create geometry and material
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute(
      'position',
      new THREE.BufferAttribute(this.positions, 3)
    )

    const material = new THREE.PointsMaterial({
      color: 0xff3131, // Lobster Red
      size: 0.03,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    })

    this.points = new THREE.Points(geometry, material)
    this.scene.add(this.points)

    // Handle window resize
    this.onWindowResize = this.onWindowResize.bind(this)
    window.addEventListener('resize', this.onWindowResize)
  }

  startEmergenceAnimation(duration: number = 3000, onComplete?: () => void) {
    this.emergenceStartTime = performance.now()
    this.emergenceDuration = duration
    this.onCompleteCallback = onComplete || null
    this.isAnimating = true
  }

  animate(time: number, deltaTime: number) {
    if (this.isDisposed || !this.isAnimating) {
      this.renderer.render(this.scene, this.camera)
      return
    }

    const positionsArr = this.points.geometry.attributes.position.array as Float32Array
    const currentTime = performance.now()
    const elapsed = currentTime - (this.emergenceStartTime || 0)
    const progress = Math.min(elapsed / (this.emergenceDuration || 3000), 1)

    // Emergence animation: particles rise from bottom
    if (progress < 1) {
      for (let i = 0; i < this.particleCount; i++) {
        const i3 = i * 3

        // Calculate emergence height (0 to 1)
        const startY = -5
        const targetY = this.originalPositions[i * 3 + 1]
        const emergenceY = startY + (targetY - startY) * progress

        positionsArr[i * 3] = this.originalPositions[i * 3]
        positionsArr[i * 3 + 1] = emergenceY
        positionsArr[i * 3 + 2] = this.originalPositions[i * 3 + 2]
      }
    } else {
      // Animation complete
      for (let i = 0; i < this.particleCount; i++) {
        const i3 = i * 3
        positionsArr[i3] = this.originalPositions[i3]
        positionsArr[i3 + 1] = this.originalPositions[i3 + 1]
        positionsArr[i3 + 2] = this.originalPositions[i3 + 2]
      }

      this.isAnimating = false
      if (this.onCompleteCallback) {
        this.onCompleteCallback()
      }
    }

    this.points.geometry.attributes.position.needsUpdate = true

    // Subtle rotation
    this.points.rotation.y += 0.0015
    this.points.rotation.x += 0.0008

    this.renderer.render(this.scene, this.camera)
  }

  onWindowResize() {
    if (this.isDisposed) return

    const width = window.innerWidth
    const height = window.innerHeight

    this.camera.aspect = width / height
    this.camera.updateProjectionMatrix()
    this.renderer.setSize(width, height)
  }

  dispose() {
    if (this.isDisposed) return

    this.isDisposed = true
    this.isAnimating = false
    window.removeEventListener('resize', this.onWindowResize)

    // Dispose geometry and material
    this.points.geometry?.dispose()
    if (Array.isArray(this.points.material)) {
      this.points.material.forEach((m) => m.dispose())
    } else {
      this.points.material?.dispose()
    }

    this.renderer.dispose()
  }
}

export function initParticleSystem(
  canvas: HTMLCanvasElement,
  config?: Partial<ParticleSystemConfig>
): {
  scene: ParticleSystemScene
  animate: (time: number, deltaTime: number) => void
  startEmergence: (duration: number, onComplete?: () => void) => void
  dispose: () => void
} {
  const scene = new ParticleSystemScene(canvas, config)

  return {
    scene,
    animate: (time: number, deltaTime: number) => scene.animate(time, deltaTime),
    startEmergence: (duration: number, onComplete?: () => void) =>
      scene.startEmergenceAnimation(duration, onComplete),
    dispose: () => scene.dispose()
  }
}
